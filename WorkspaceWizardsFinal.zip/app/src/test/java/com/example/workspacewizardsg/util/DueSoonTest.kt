package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.WorkOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.util.Calendar

class DueSoonTest {

    private fun at(day: Int, hour: Int = 9): Long = Calendar.getInstance().apply {
        clear()
        set(2026, Calendar.NOVEMBER, day, hour, 0, 0)
    }.timeInMillis

    // Monday 9 Nov 2026, 13:00
    private val now = at(day = 9, hour = 13)

    private fun order(scheduledAt: Long, status: String = "PENDING") =
        WorkOrder(workOrderId = scheduledAt.toString(), scheduledAt = scheduledAt, status = status)

    @Test
    fun laterTodayIsDueToday() {
        assertEquals(DueStatus("Due today", true), dueStatus(order(at(9, 17)), now))
    }

    @Test
    fun earlierTodayIsStillDueToday() {
        assertEquals(DueStatus("Due today", true), dueStatus(order(at(9, 8)), now))
    }

    @Test
    fun tomorrowAndTheDayAfterAreDueSoon() {
        assertEquals(DueStatus("Due tomorrow", false), dueStatus(order(at(10)), now))
        assertEquals(DueStatus("Due in 2 days", false), dueStatus(order(at(11)), now))
    }

    @Test
    fun threeDaysAwayIsNotDueSoon() {
        assertNull(dueStatus(order(at(12)), now))
    }

    @Test
    fun aPastDayIsOverdue() {
        assertEquals(DueStatus("Overdue", true), dueStatus(order(at(8)), now))
    }

    @Test
    fun onlyPendingJobsCanBeDue() {
        assertNull(dueStatus(order(at(9, 17), status = "IN_PROGRESS"), now))
        assertNull(dueStatus(order(at(9, 17), status = "COMPLETED"), now))
    }

    @Test
    fun olderJobsWithoutADateAreIgnored() {
        assertNull(dueStatus(order(0L), now))
    }

    @Test
    fun dueJobsMoveToTheTopSoonestFirst() {
        val orders = listOf(order(at(20)), order(at(11)), order(at(8)), order(at(15)), order(at(10)))
        val sorted = sortDueSoonFirst(orders, now).map { it.scheduledAt }
        assertEquals(listOf(at(8), at(10), at(11), at(20), at(15)), sorted)
    }

    @Test
    fun dueMessagesListOnlyDueJobsSoonestFirst() {
        val orders = listOf(
            order(at(11)).copy(clientName = "Later Co"),
            order(at(20)).copy(clientName = "Far Co"),
            order(at(8)).copy(clientName = "Late Co"),
            order(at(10), status = "COMPLETED").copy(clientName = "Done Co")
        )
        assertEquals(
            listOf("Overdue: Late Co", "Due in 2 days: Later Co"),
            dueSoonMessages(orders, now)
        )
    }
}
