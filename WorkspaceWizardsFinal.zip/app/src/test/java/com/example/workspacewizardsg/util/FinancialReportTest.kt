package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.Invoice
import com.example.workspacewizardsg.model.WorkOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class FinancialReportTest {

    private fun at(month: Int, day: Int): Long = Calendar.getInstance().apply {
        clear(); set(2026, month, day, 10, 0, 0)
    }.timeInMillis

    private val now = at(Calendar.NOVEMBER, 12)

    private fun job(amount: Double, status: String = "COMPLETED", completedAt: Long = 0L, createdAt: Long = 0L) =
        WorkOrder(amountZAR = amount, status = status, completedAt = completedAt, createdAt = createdAt)

    private fun invoice(number: String, amount: Double, status: String, issued: Long) =
        Invoice(invoiceNumber = number, clientName = "Client $number", amountZAR = amount, paymentStatus = status, issuedDate = issued)

    @Test
    fun totalsSeparatePaidFromUnpaid() {
        val report = buildFinancialReport(
            orders = listOf(job(1000.0), job(500.0), job(300.0, status = "PENDING")),
            invoices = listOf(
                invoice("INV-0001", 1000.0, "PAID", at(Calendar.OCTOBER, 1)),
                invoice("INV-0002", 500.0, "UNPAID", at(Calendar.NOVEMBER, 2))
            ),
            now = now
        )
        assertEquals(2, report.completedJobs)
        assertEquals(1500.0, report.revenue, 0.001)
        assertEquals(1000.0, report.collected, 0.001)
        assertEquals(1, report.collectedCount)
        assertEquals(500.0, report.outstanding, 0.001)
        assertEquals(1, report.outstandingCount)
    }

    @Test
    fun invoicesListNewestFirst() {
        val report = buildFinancialReport(
            emptyList(),
            listOf(
                invoice("INV-0001", 1.0, "PAID", at(Calendar.AUGUST, 1)),
                invoice("INV-0003", 1.0, "PAID", at(Calendar.NOVEMBER, 1)),
                invoice("INV-0002", 1.0, "PAID", at(Calendar.OCTOBER, 1))
            ),
            now
        )
        assertEquals(listOf("INV-0003", "INV-0002", "INV-0001"), report.invoices.map { it.number })
    }

    @Test
    fun monthlyRevenueUsesTheCompletionMonth() {
        // Added in September but completed in November: counts in November
        val orders = listOf(
            job(800.0, completedAt = at(Calendar.NOVEMBER, 5), createdAt = at(Calendar.SEPTEMBER, 20)),
            job(200.0, completedAt = 0L, createdAt = at(Calendar.OCTOBER, 3)),   // older job: falls back to created
            job(999.0, status = "PENDING", createdAt = at(Calendar.NOVEMBER, 1))
        )
        val months = revenueByMonth(orders, months = 6, now = now)
        assertEquals(6, months.size)
        assertEquals(800.0, months.last().amount, 0.001)       // November
        assertEquals(200.0, months[4].amount, 0.001)           // October
        assertEquals(0.0, months[3].amount, 0.001)             // September
    }

    @Test
    fun randFormatting() {
        assertEquals("R 0.00", formatRand(0.0))
        assertEquals("R 850.00", formatRand(850.0))
        assertEquals("R 12 345.50", formatRand(12345.5))
        assertEquals("R 1 000 000.00", formatRand(1_000_000.0))
        assertEquals("R950", compactRand(950.0))
        assertEquals("R12.5k", compactRand(12_500.0))
        assertEquals("R1.2M", compactRand(1_200_000.0))
    }

    @Test
    fun longNamesAreShortened() {
        assertEquals("Short", ellipsize("Short", 10))
        assertEquals(10, ellipsize("A very long company name", 10).length)
        assertTrue(ellipsize("A very long company name", 10).endsWith("…"))
    }
}
