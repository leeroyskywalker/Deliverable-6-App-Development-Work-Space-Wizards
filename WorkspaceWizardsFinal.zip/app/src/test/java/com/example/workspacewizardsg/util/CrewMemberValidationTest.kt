package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.CrewMember
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CrewMemberValidationTest {

    private val team = listOf(CrewMember(memberId = "m1", crewId = "c1", firstName = "Thabo", lastName = "Mokoena"))

    @Test
    fun validNewMemberIsAccepted() {
        assertNull(crewMemberError("Sipho", "Khumalo", team))
    }

    @Test
    fun blankOrNumericNamesAreRejected() {
        assertNotNull(crewMemberError("", "Khumalo", team))
        assertNotNull(crewMemberError("Sipho", "   ", team))
        assertNotNull(crewMemberError("123", "Khumalo", team))
        assertNotNull(crewMemberError("Sipho", "K4", team))
    }

    @Test
    fun duplicateNameIsRejectedIgnoringCase() {
        assertNotNull(crewMemberError("thabo", "MOKOENA", team))
    }

    @Test
    fun editingAMemberDoesNotClashWithThemselves() {
        assertNull(crewMemberError("Thabo", "Mokoena", team, editingId = "m1"))
    }
}
