package com.example.workspacewizardsg.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportLayoutTest {

    private fun report(invoiceCount: Int, months: List<MonthRevenue> = sixMonths()) = FinancialReport(
        generatedAt = 1_762_900_000_000L,
        completedJobs = invoiceCount,
        revenue = 1000.0 * invoiceCount,
        months = months,
        invoices = (1..invoiceCount).map { InvoiceLine("INV-%04d".format(it), "Client $it", 1_762_000_000_000L, 1000.0, it % 2 == 0) }
    )

    private fun sixMonths(amounts: List<Double> = listOf(0.0, 500.0, 1000.0, 2000.0, 0.0, 4000.0)) =
        listOf("Jun", "Jul", "Aug", "Sep", "Oct", "Nov").zip(amounts) { l, a -> MonthRevenue(l, a) }

    private fun texts(page: List<DrawOp>) = page.filterIsInstance<DrawOp.Text>().map { it.text }

    @Test
    fun aSmallReportFitsOnePage() {
        val pages = layoutReport(report(5))
        assertEquals(1, pages.size)
        assertTrue("Page 1 of 1" in texts(pages[0]))
    }

    @Test
    fun aLongInvoiceListContinuesOnMorePagesAndRepeatsTheHeader() {
        val pages = layoutReport(report(120))
        assertTrue(pages.size >= 3)
        pages.drop(1).forEach { assertTrue("Invoices (continued)" in texts(it)) }
        pages.forEachIndexed { i, p -> assertTrue("Page ${i + 1} of ${pages.size}" in texts(p)) }
        // every invoice is listed exactly once
        val listed = pages.flatMap { texts(it) }.filter { it.startsWith("INV-") }
        assertEquals((1..120).map { "INV-%04d".format(it) }, listed)
    }

    @Test
    fun nothingIsDrawnOutsideThePage() {
        layoutReport(report(120)).forEach { page ->
            page.forEach { op ->
                when (op) {
                    is DrawOp.Rect -> assertTrue(op.x >= 0 && op.y >= 0 && op.x + op.w <= PAGE_WIDTH && op.y + op.h <= PAGE_HEIGHT)
                    is DrawOp.Line -> assertTrue(op.x1 >= 0 && op.x2 <= PAGE_WIDTH && op.y1 <= PAGE_HEIGHT)
                    is DrawOp.Text -> assertTrue(op.x in 0f..PAGE_WIDTH.toFloat() && op.y in 0f..PAGE_HEIGHT.toFloat())
                }
            }
        }
    }

    @Test
    fun tableRowsNeverReachTheFooter() {
        layoutReport(report(120)).forEach { page ->
            val rowBottoms = page.filterIsInstance<DrawOp.Line>().map { it.y1 }
            assertTrue(rowBottoms.all { it <= PAGE_HEIGHT - 60f })
        }
    }

    @Test
    fun barHeightsAreInProportionAndEmptyMonthsHaveNoBar() {
        val bars = layoutReport(report(1))[0].filterIsInstance<DrawOp.Rect>().filter { it.w == 40f }
        assertEquals(4, bars.size)                       // 4 of the 6 months have revenue
        val tallest = bars.maxOf { it.h }
        val smallest = bars.minOf { it.h }
        assertEquals(95f, tallest, 0.01f)
        assertEquals(95f * 500 / 4000, smallest, 0.01f)
    }

    @Test
    fun noRevenueShowsAMessageInsteadOfAChart() {
        val page = layoutReport(report(0, sixMonths(List(6) { 0.0 })))[0]
        assertTrue("No completed jobs yet" in texts(page))
        assertTrue("No invoices yet" in texts(page))
        assertTrue(page.filterIsInstance<DrawOp.Rect>().none { it.w == 40f })
    }

    @Test
    fun figuresShowThePaidAndUnpaidSplit() {
        val page = layoutReport(
            report(2).copy(revenue = 3000.0, collected = 1000.0, collectedCount = 1, outstanding = 2000.0, outstandingCount = 1)
        )[0]
        val t = texts(page)
        assertTrue("R 3 000.00" in t && "R 1 000.00" in t && "R 2 000.00" in t)
        assertTrue("1 paid invoice" in t && "1 unpaid invoice" in t)
    }
}
