package com.example.workspacewizardsg.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ClientMessagesTest {

    @Test
    fun greetsTheContactPersonWhenThereIsOne() {
        assertEquals("Thabo", greetingName("Thabo", "Mokoena Traders"))
        assertEquals("Mokoena Traders", greetingName("  ", "Mokoena Traders"))
    }

    @Test
    fun messagesNameTheCrewAndTheSite() {
        assertEquals(
            "Hi Thabo, this is Crew 2 from Workspace Wizards. We're on our way to 12 Main Road.",
            onTheWayMessage("Thabo", "Crew 2", "12 Main Road")
        )
        assertEquals(
            "Hi Thabo, Crew 2 from Workspace Wizards has started your job at 12 Main Road.",
            jobStartedMessage("Thabo", "Crew 2", "12 Main Road")
        )
    }

    @Test
    fun adminMessageMentionsTheScheduleOnlyWhenKnown() {
        assertEquals(
            "Hi Thabo, this is Workspace Wizards about your job at 12 Main Road scheduled for Fri 13 Nov 2026, 09:00.",
            adminJobMessage("Thabo", "12 Main Road", "Fri 13 Nov 2026, 09:00")
        )
        assertEquals(
            "Hi Thabo, this is Workspace Wizards about your job at 12 Main Road.",
            adminJobMessage("Thabo", "12 Main Road", "")
        )
    }

    @Test
    fun linkUsesTheInternationalNumberAndEncodesTheText() {
        assertEquals(
            "https://wa.me/27821234567?text=Hi%20Thabo%2C%20we%27re%20on%20our%20way%20%26%20nearly%20there.",
            whatsAppUrl("082 123 4567", "Hi Thabo, we're on our way & nearly there.")
        )
    }

    @Test
    fun invalidPhoneGivesNoLink() {
        assertNull(whatsAppUrl("12345", "Hi"))
        assertNull(whatsAppUrl("", "Hi"))
    }
}
