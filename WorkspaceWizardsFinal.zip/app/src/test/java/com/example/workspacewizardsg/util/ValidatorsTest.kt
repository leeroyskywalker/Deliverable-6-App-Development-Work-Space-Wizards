package com.example.workspacewizardsg.util

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ValidatorsTest {

    @Test
    fun personName_acceptsRealNames() {
        listOf("Thabiso", "Mary-Jane", "O'Neil", "van der Merwe", "Zoë").forEach {
            assertNull(it, personNameError(it))
        }
    }

    @Test
    fun personName_rejectsNumbersSymbolsAndBlanks() {
        listOf("12345", "John3", "  ", "", "A", "John@", "John  Smith").forEach {
            assertNotNull(it, personNameError(it))
        }
    }

    @Test
    fun companyName_allowsDigitsButNeedsALetter() {
        listOf("3M South Africa", "Smith & Sons (Pty) Ltd", "Pick n Pay 24").forEach {
            assertNull(it, companyNameError(it))
        }
        listOf("12345", "!!!", "   ", "").forEach {
            assertNotNull(it, companyNameError(it))
        }
    }

    @Test
    fun phone_acceptsTenDigitLocalNumbers() {
        listOf("0821234567", "082 123 4567", "082-123-4567", "  0821234567 ").forEach {
            assertNull(it, phoneError(it))
        }
    }

    @Test
    fun phone_rejectsWrongLengthPrefixAndFakeNumbers() {
        listOf(
            "", "082123456", "08212345678", "+27821234567", "1821234567",
            "0000000000", "0111111111", "0012345678", "082abc4567"
        ).forEach { assertNotNull(it, phoneError(it)) }
    }

    @Test
    fun email_acceptsUniversalFormat() {
        listOf("name@company.co.za", "a.b+tag@mail.example.com", "  user@site.org ").forEach {
            assertNull(it, emailError(it))
        }
    }

    @Test
    fun email_rejectsBrokenFormats() {
        listOf(
            "", "name", "name@", "@company.com", "name@company", "name@@company.com",
            "na me@company.com", "name@company..com", ".name@company.com", "name@company.c"
        ).forEach { assertNotNull(it, emailError(it)) }
    }

    @Test
    fun email_canBeOptional() {
        assertNull(emailError("", required = false))
        assertNotNull(emailError("bad", required = false))
    }

    @Test
    fun address_needsLettersAndLength() {
        assertNull(addressError("12 Main Road, Sandton"))
        listOf("", "12345", "ab").forEach { assertNotNull(it, addressError(it)) }
    }

    @Test
    fun serviceDetails_needsRealDescription() {
        assertNull(serviceDetailsError("Move 10 desks to floor 3"))
        listOf("", "move", "1234567890").forEach { assertNotNull(it, serviceDetailsError(it)) }
    }

    @Test
    fun amount_mustBePositiveAndSensible() {
        listOf("1500", "1500.50", "0.5").forEach { assertNull(it, amountError(it)) }
        listOf("", "0", "0.00", "abc", "2000000").forEach { assertNotNull(it, amountError(it)) }
    }

    @Test
    fun scheduled_mustBeInTheFuture() {
        val now = 1_000_000L
        assertNotNull(scheduledError(null, now))
        assertNotNull(scheduledError(now - 1, now))
        assertNotNull(scheduledError(now, now))
        assertNull(scheduledError(now + 1, now))
    }

    @Test
    fun scheduled_unchangedPastDateIsAllowedWhenEditing() {
        val now = 1_000_000L
        assertNull(scheduledError(500L, now, original = 500L))
        assertNotNull(scheduledError(600L, now, original = 500L))
    }
}
