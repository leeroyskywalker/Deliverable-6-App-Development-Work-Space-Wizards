package com.example.workspacewizardsg.util

import org.junit.Assert.assertEquals
import org.junit.Test

class DateTimeFormatTest {

    private val minute = 60_000L

    @Test
    fun duration_underAMinute() {
        assertEquals("Less than 1 min", formatDuration(0, 30_000))
    }

    @Test
    fun duration_minutesOnly() {
        assertEquals("45 min", formatDuration(0, 45 * minute))
    }

    @Test
    fun duration_hoursAndMinutes() {
        assertEquals("1 h 20 min", formatDuration(0, 80 * minute))
    }

    @Test
    fun duration_wholeHours() {
        assertEquals("2 h", formatDuration(0, 120 * minute))
    }

    @Test
    fun duration_endBeforeStartIsTreatedAsZero() {
        assertEquals("Less than 1 min", formatDuration(10 * minute, 0))
    }
}
