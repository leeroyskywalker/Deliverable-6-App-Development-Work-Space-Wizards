package com.example.workspacewizardsg.util

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CrewAccountValidationTest {

    private val names = listOf("Crew 1", "Crew 2")
    private val emails = listOf("crew1@workspacewizards.co.za")

    @Test
    fun goodCrewNameIsAccepted() {
        assertNull(crewNameError("Crew 3", names))
        assertNull(crewNameError("  Alpha Team ", names))
    }

    @Test
    fun badCrewNamesAreRejected() {
        assertNotNull(crewNameError("", names))
        assertNotNull(crewNameError("C", names))
        assertNotNull(crewNameError("12345", names))
        assertNotNull(crewNameError("Crew @3", names))
        assertNotNull(crewNameError("A".repeat(31), names))
    }

    @Test
    fun duplicateCrewNameIgnoresCaseAndSpaces() {
        assertNotNull(crewNameError(" crew 1 ", names))
    }

    @Test
    fun crewEmailMustBeValidAndNew() {
        assertNull(crewEmailError("crew3@workspacewizards.co.za", emails))
        assertNotNull(crewEmailError("crew3", emails))
        assertNotNull(crewEmailError("CREW1@workspacewizards.co.za ", emails))
    }

    @Test
    fun passwordNeedsLengthLettersAndNumbers() {
        assertNull(passwordError("Wizards2026"))
        assertNotNull(passwordError(""))
        assertNotNull(passwordError("short1"))
        assertNotNull(passwordError("onlyletters"))
        assertNotNull(passwordError("12345678"))
        assertNotNull(passwordError("has space 1234"))
    }

    @Test
    fun messageMustHaveTextAndStayShort() {
        assertNull(messageError("Please call the client before you arrive"))
        assertNotNull(messageError("   "))
        assertNotNull(messageError("x".repeat(201)))
    }
}
