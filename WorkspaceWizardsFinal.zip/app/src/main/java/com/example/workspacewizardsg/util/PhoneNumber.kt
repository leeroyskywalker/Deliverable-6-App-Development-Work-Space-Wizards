package com.example.workspacewizardsg.util

// Returns +27XXXXXXXXX (the format WhatsApp links need) or null if the number is not a valid
// South African number. Accepts 0821234567, 27821234567 and +27821234567, with spaces or dashes.
fun normaliseSaPhone(raw: String): String? {
    val cleaned = raw.filter { it.isDigit() || it == '+' }
    val e164 = when {
        cleaned.startsWith("+27") -> cleaned
        cleaned.startsWith("27") -> "+$cleaned"
        cleaned.startsWith("0") -> "+27" + cleaned.drop(1)
        else -> return null
    }
    return if (e164.matches(Regex("^\\+27\\d{9}$"))) e164 else null
}

// Saved numbers are +27XXXXXXXXX. Forms ask for the 10-digit local format, so convert back for editing.
fun toLocalPhone(stored: String): String =
    if (stored.startsWith("+27")) "0" + stored.drop(3) else stored