package com.example.workspacewizardsg.model

data class User(
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val role: String = "",
    val teamColour: String = "",
    val activeJobId: String? = null,
    val mfaEnabled: Boolean = true,
    val mfaSecret: String = ""
)