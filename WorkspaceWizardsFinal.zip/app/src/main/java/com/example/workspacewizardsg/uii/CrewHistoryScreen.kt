package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.util.formatDuration

// The crew's finished jobs, newest first, with every step time and who was on the team.
// Shown as a tab of the crew screen, so it has no top bar of its own.
@Composable
fun CrewHistoryScreen(jobs: List<WorkOrder>) {
    if (jobs.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                icon = Icons.Default.CheckCircle,
                title = "No completed jobs yet",
                message = "Finished jobs are listed here with their times and team."
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items = jobs, key = { it.workOrderId }) { job ->
                Box(modifier = Modifier.animateItem()) { HistoryCard(job) }
            }
        }
    }
}

@Composable
private fun HistoryCard(job: WorkOrder) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = job.clientName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            if (job.contactPerson.isNotBlank()) {
                Text(text = "Contact: ${job.contactPerson}", style = MaterialTheme.typography.bodyMedium)
            }
            Text(text = job.siteAddress, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = job.serviceDetails,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (job.teamMembers.isNotEmpty()) {
                Text(
                    text = "Team: ${job.teamMembers.joinToString(", ")}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            StepTime("Claimed", job.claimedAt)
            StepTime("On my way", job.onTheWayAt)
            StepTime("Started", job.startedAt)
            StepTime("Completed", job.completedAt)
            if (job.startedAt > 0 && job.completedAt > 0) {
                Text(
                    text = "Duration: ${formatDuration(job.startedAt, job.completedAt)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}