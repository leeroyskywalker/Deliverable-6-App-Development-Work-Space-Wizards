package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.CrewAccount
import com.example.workspacewizardsg.repository.CrewAccountRepository
import com.example.workspacewizardsg.repository.CrewMemberRepository
import com.example.workspacewizardsg.repository.NotificationRepository
import com.example.workspacewizardsg.repository.WorkOrderRepository
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// currentClient is the client of the job the crew is working on, or null when the crew is free
data class CrewRow(
    val crew: CrewAccount,
    val currentClient: String?,
    val membersAvailable: Int,
    val membersTotal: Int
)

data class CrewsUiState(
    val crews: List<CrewRow> = emptyList(),
    val isLoading: Boolean = true,
    val isBusy: Boolean = false,
    val message: String? = null
)

class CrewsViewModel(
    private val accountRepository: CrewAccountRepository = CrewAccountRepository(),
    workOrderRepository: WorkOrderRepository = WorkOrderRepository(),
    memberRepository: CrewMemberRepository = CrewMemberRepository(),
    private val notificationRepository: NotificationRepository = NotificationRepository()
) : ViewModel() {

    private val _isBusy = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)

    // .catch: after sign-out Firestore rejects open listeners, which must not crash the app
    val uiState: StateFlow<CrewsUiState> = combine(
        accountRepository.observeCrews().catch { emit(emptyList()) },
        workOrderRepository.observeAllWorkOrders().catch { emit(emptyList()) },
        memberRepository.observeAllMembers().catch { emit(emptyList()) },
        _isBusy,
        _message
    ) { crews, orders, members, busy, message ->
        CrewsUiState(
            crews = crews.map { crew ->
                val team = members.filter { it.crewId == crew.userId }
                CrewRow(
                    crew = crew,
                    // Read from the jobs themselves: a job in progress is the truth, activeJobId is only a pointer
                    currentClient = orders.firstOrNull {
                        it.status == "IN_PROGRESS" && it.assignedCrew == crew.userId
                    }?.clientName,
                    membersAvailable = team.count { it.available },
                    membersTotal = team.size
                )
            },
            isLoading = false,
            isBusy = busy,
            message = message
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = CrewsUiState()
    )

    fun addCrew(name: String, email: String, password: String, colour: String, onAdded: () -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            accountRepository.createCrew(name.trim(), email.trim(), password, colour).fold(
                onSuccess = {
                    _message.value = "${name.trim()} added. Share the email and password with the crew."
                    onAdded()
                },
                onFailure = { e ->
                    _message.value = if (e is FirebaseAuthUserCollisionException) "That email already has an account"
                    else "Could not add the crew. Check your connection."
                }
            )
            _isBusy.value = false
        }
    }

    fun messageCrew(crew: CrewAccount, text: String, onSent: () -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            notificationRepository.send(crew.userId, "Admin: ${text.trim()}").fold(
                onSuccess = {
                    _message.value = "Message sent to ${crew.fullName}"
                    onSent()
                },
                onFailure = { _message.value = "Could not send the message. Check your connection." }
            )
            _isBusy.value = false
        }
    }

    fun clearMessage() { _message.value = null }
}

