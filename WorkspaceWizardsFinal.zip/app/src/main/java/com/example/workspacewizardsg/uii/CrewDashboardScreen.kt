package com.example.workspacewizardsg.uii

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.util.dueSoonMessages
import com.example.workspacewizardsg.viewmodel.CrewViewModel
import com.example.workspacewizardsg.viewmodel.NotificationViewModel
import com.example.workspacewizardsg.viewmodel.TeamViewModel

private enum class CrewTab(val label: String, val icon: ImageVector) {
    JOBS("Jobs", Icons.AutoMirrored.Filled.List),
    TEAM("Team", Icons.Default.AccountCircle),
    HISTORY("History", Icons.Default.CheckCircle)
}

// The crew's home: one top bar and a tab bar that switches between Jobs, Team and History.
// The tab bar is at the bottom, or down the left side when the screen is too short for it.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrewDashboardScreen(
    onSignOut: () -> Unit,
    crewViewModel: CrewViewModel = viewModel(),
    teamViewModel: TeamViewModel = viewModel(),
    notificationViewModel: NotificationViewModel = viewModel()
) {
    val uiState by crewViewModel.uiState.collectAsState()
    val notifications by notificationViewModel.notifications.collectAsState()
    val members by teamViewModel.members.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val compact = isCompactHeight()
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()
    var selectedTab by rememberSaveable { mutableStateOf(0) }

    // Solid team colour for the top bar, a light tint of it for the page background
    val teamColour = parseTeamColour(uiState.teamColour) ?: MaterialTheme.colorScheme.primary
    val onTeamColour = if (teamColour.luminance() > 0.5f) Color.Black else Color.White
    val pageTint = teamColour.copy(alpha = 0.12f).compositeOver(MaterialTheme.colorScheme.background)

    LaunchedEffect(crewViewModel.crewUserId) {
        crewViewModel.crewUserId?.let(notificationViewModel::start)
    }

    // Opens the pre-filled WhatsApp message to the client, once
    LaunchedEffect(uiState.clientChatUrl) {
        uiState.clientChatUrl?.let {
            openWhatsAppChat(context, it)
            crewViewModel.clearClientChat()
        }
    }

    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            crewViewModel.clearMessage()
        }
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        containerColor = pageTint,
        topBar = {
            BrandTopBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // White tile keeps the logo readable on any team colour
                        Surface(color = Color.White, shape = RoundedCornerShape(8.dp)) {
                            WizardLogo(size = 28.dp, modifier = Modifier.padding(2.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(uiState.crewName.ifBlank { "Field Crew" })
                    }
                },
                actions = {
                    NotificationBell(
                        notifications = notifications,
                        dueMessages = dueSoonMessages(listOfNotNull(uiState.activeJob) + uiState.pendingJobs),
                        onClosed = notificationViewModel::markAllRead
                    )
                    IconButton(onClick = onSignOut) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Sign out")
                    }
                },
                containerColor = teamColour,
                contentColor = onTeamColour,
                scrollBehavior = scrollBehavior
            )
        },
        bottomBar = {
            if (!compact) CrewNavigationBar(selectedTab) { selectedTab = it }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (compact) CrewNavigationRail(selectedTab) { selectedTab = it }
            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                Crossfade(targetState = selectedTab, label = "crewTab") { tab ->
                    when (CrewTab.values()[tab]) {
                        CrewTab.JOBS -> CrewJobsScreen(
                            uiState = uiState,
                            members = members.orEmpty(),
                            onTakeJob = crewViewModel::takeJob,
                            onMyWay = crewViewModel::onMyWay,
                            onStart = crewViewModel::startJob,
                            onComplete = crewViewModel::completeJob,
                            onRelease = crewViewModel::releaseJob
                        )
                        CrewTab.TEAM -> TeamScreen(
                            snackbarHostState = snackbarHostState,
                            viewModel = teamViewModel
                        )
                        CrewTab.HISTORY -> CrewHistoryScreen(jobs = uiState.completedJobs)
                    }
                }
            }
        }
    }
}

@Composable
private fun CrewNavigationBar(selectedTab: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        CrewTab.values().forEachIndexed { index, tab ->
            NavigationBarItem(
                selected = selectedTab == index,
                onClick = { onSelect(index) },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.tertiary,
                    selectedTextColor = MaterialTheme.colorScheme.tertiary,
                    indicatorColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)
                )
            )
        }
    }
}

// The same tabs down the left edge, for screens that are short (a phone held sideways).
// Its insets are zero because the Scaffold's padding already keeps it clear of the system bars.
@Composable
private fun CrewNavigationRail(selectedTab: Int, onSelect: (Int) -> Unit) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surface,
        windowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp)
    ) {
        CrewTab.values().forEachIndexed { index, tab ->
            NavigationRailItem(
                selected = selectedTab == index,
                onClick = { onSelect(index) },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.tertiary,
                    selectedTextColor = MaterialTheme.colorScheme.tertiary,
                    indicatorColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)
                )
            )
        }
    }
}

internal fun parseTeamColour(hex: String): Color? =
    runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrNull()