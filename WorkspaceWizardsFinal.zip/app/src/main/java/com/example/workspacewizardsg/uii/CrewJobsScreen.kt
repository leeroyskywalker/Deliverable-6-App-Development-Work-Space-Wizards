package com.example.workspacewizardsg.uii

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.workspacewizardsg.model.CrewMember
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.model.fullName
import com.example.workspacewizardsg.util.dueStatus
import com.example.workspacewizardsg.util.formatDateTime
import com.example.workspacewizardsg.util.sortDueSoonFirst
import com.example.workspacewizardsg.viewmodel.CrewUiState

// The Jobs tab: the active job with its steps, and the jobs any crew can take.
// Shown as a tab of the crew screen, so it has no top bar of its own.
@Composable
fun CrewJobsScreen(
    uiState: CrewUiState,
    members: List<CrewMember>,
    onTakeJob: (workOrderId: String) -> Unit,
    onMyWay: () -> Unit,
    onStart: (teamMembers: List<String>) -> Unit,
    onComplete: () -> Unit,
    onRelease: () -> Unit
) {
    var showStartDialog by remember { mutableStateOf(false) }
    var showCompleteDialog by remember { mutableStateOf(false) }
    var showReleaseDialog by remember { mutableStateOf(false) }

    if (uiState.isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            uiState.activeJob?.let { job ->
                item { SectionTitle("Your active job") }
                item {
                    // Steps in order: On my way (optional) -> Start Job -> Complete Job
                    JobCard(job = job, maxDetailLines = Int.MAX_VALUE) {
                        if (job.startedAt == 0L) {
                            if (job.onTheWayAt == 0L) {
                                OutlinedButton(
                                    onClick = onMyWay,
                                    enabled = !uiState.isBusy,
                                    modifier = Modifier.fillMaxWidth()
                                ) { ButtonLabel(Icons.AutoMirrored.Filled.Send, "On my way") }
                            }
                            Button(
                                onClick = { showStartDialog = true },
                                enabled = !uiState.isBusy,
                                modifier = Modifier.fillMaxWidth()
                            ) { ButtonLabel(Icons.Default.PlayArrow, "Start Job") }
                        } else {
                            Button(
                                onClick = { showCompleteDialog = true },
                                enabled = !uiState.isBusy,
                                modifier = Modifier.fillMaxWidth()
                            ) { ButtonLabel(Icons.Default.Check, "Complete Job") }
                        }
                        OutlinedButton(
                            onClick = { showReleaseDialog = true },
                            enabled = !uiState.isBusy,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Release Job") }
                    }
                }
            }

            item { SectionTitle("Available jobs") }
            if (uiState.activeJob != null) {
                item {
                    Text(
                        text = "Finish your current job to take another.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (uiState.pendingJobs.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.AutoMirrored.Filled.List,
                        title = "No jobs available right now",
                        message = "New jobs appear here as soon as the admin adds them."
                    )
                }
            } else {
                items(sortDueSoonFirst(uiState.pendingJobs), key = { it.workOrderId }) { job ->
                    Box(modifier = Modifier.animateItem()) {
                        JobCard(job = job, maxDetailLines = 3) {
                            Button(
                                onClick = { onTakeJob(job.workOrderId) },
                                enabled = uiState.activeJob == null && !uiState.isBusy,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Take This Job") }
                        }
                    }
                }
            }
        }
    }

    if (showStartDialog) {
        StartJobDialog(
            members = members,
            onConfirm = { names ->
                showStartDialog = false
                onStart(names)
            },
            onDismiss = { showStartDialog = false }
        )
    }

    if (showCompleteDialog) {
        AlertDialog(
            onDismissRequest = { showCompleteDialog = false },
            title = { Text("Complete this job?") },
            text = { Text("The job will be marked as completed. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    showCompleteDialog = false
                    onComplete()
                }) { Text("Complete") }
            },
            dismissButton = {
                TextButton(onClick = { showCompleteDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showReleaseDialog) {
        AlertDialog(
            onDismissRequest = { showReleaseDialog = false },
            title = { Text("Release this job?") },
            text = {
                Text("The job goes back to Pending and every crew, including you, can take it.")
            },
            confirmButton = {
                TextButton(onClick = {
                    showReleaseDialog = false
                    onRelease()
                }) { Text("Release") }
            },
            dismissButton = {
                TextButton(onClick = { showReleaseDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// The leader ticks who is working on this job. Only available members can be picked, and at
// least one is needed. The names are saved on the job, so the history stays correct even if
// the team changes later.
@Composable
private fun StartJobDialog(
    members: List<CrewMember>,
    onConfirm: (teamMembers: List<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val available = members.filter { it.available }
    var selectedIds by remember { mutableStateOf(available.map { it.memberId }.toSet()) }
    val chosen = available.filter { it.memberId in selectedIds }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Start this job now?") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                when {
                    members.isEmpty() -> Text(
                        "Add at least one team member in the Team tab before you start a job."
                    )
                    available.isEmpty() -> Text(
                        "Everyone in your team is marked unavailable. Update the Team tab first."
                    )
                    else -> {
                        Text(
                            text = "Who is working on this job? The start time is recorded now " +
                                    "and can't be changed.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        available.forEach { member ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedIds = if (member.memberId in selectedIds)
                                            selectedIds - member.memberId
                                        else selectedIds + member.memberId
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = member.memberId in selectedIds,
                                    onCheckedChange = null
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(member.fullName)
                            }
                        }
                        if (chosen.isEmpty()) {
                            Text(
                                text = "Select at least one team member",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(chosen.map { it.fullName }) },
                enabled = chosen.isNotEmpty()
            ) { Text("Start") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(text = text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
}

// A button label with a small icon in front of the text
@Composable
private fun ButtonLabel(icon: ImageVector, text: String) {
    Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
    Spacer(modifier = Modifier.width(8.dp))
    Text(text)
}

// One line of job information with a small icon in front
@Composable
private fun InfoLine(icon: ImageVector, content: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

// The job details and the times of each step so far. The buttons are supplied by the caller.
@Composable
private fun JobCard(
    job: WorkOrder,
    maxDetailLines: Int,
    actions: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = job.clientName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            InfoLine(Icons.Default.Place) { Text(text = job.siteAddress, style = MaterialTheme.typography.bodyMedium) }
            Text(
                text = job.serviceDetails,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = maxDetailLines,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = "Scheduled: ${job.scheduledTime}", style = MaterialTheme.typography.labelMedium)
                dueStatus(job)?.let { DueBadge(it) }
            }
            Text(
                text = "Added: ${formatDateTime(job.createdAt)}",
                style = MaterialTheme.typography.labelMedium
            )
            InfoLine(Icons.Default.Phone) { Text(text = job.clientPhone, style = MaterialTheme.typography.labelMedium) }
            StepTime("Claimed", job.claimedAt)
            StepTime("On my way", job.onTheWayAt)
            StepTime("Started", job.startedAt)
            if (job.teamMembers.isNotEmpty()) {
                Text(
                    text = "Team: ${job.teamMembers.joinToString(", ")}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            actions()
        }
    }
}

// Shows a step's date and time once it has happened (also used by the History tab)
@Composable
internal fun StepTime(label: String, millis: Long) {
    if (millis > 0) {
        Text(
            text = "$label: ${formatDateTime(millis)}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
    }
}