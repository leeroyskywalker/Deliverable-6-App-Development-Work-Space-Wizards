package com.example.workspacewizardsg.model

// A crew's login as the admin sees it. Built from the users collection by hand,
// so nothing sensitive in that document (such as the MFA secret) is ever read into the app.
data class CrewAccount(
    val userId: String,
    val fullName: String,
    val email: String,
    val teamColour: String
)

