package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.repository.ClientRepository
import com.example.workspacewizardsg.repository.WorkOrderRepository
import com.example.workspacewizardsg.util.filterAndSortClients
import com.example.workspacewizardsg.util.searchWorkOrders
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class SearchData(
    val clients: List<Client> = emptyList(),
    val workOrders: List<WorkOrder> = emptyList(),
    val isLoading: Boolean = true
)

class SearchViewModel(
    workOrderRepository: WorkOrderRepository = WorkOrderRepository(),
    clientRepository: ClientRepository = ClientRepository()
) : ViewModel() {

    val data: StateFlow<SearchData> = combine(
        clientRepository.observeClients().catch { emit(emptyList()) },
        workOrderRepository.observeAllWorkOrders().catch { emit(emptyList()) }
    ) { clients, workOrders ->
        SearchData(clients = clients, workOrders = workOrders, isLoading = false)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SearchData()
    )

    // The search text lives in the screen; these just apply it to the loaded data.
    fun matchingClients(data: SearchData, query: String): List<Client> =
        filterAndSortClients(data.clients, query)

    fun matchingWorkOrders(data: SearchData, query: String): List<WorkOrder> =
        searchWorkOrders(data.workOrders, query)
}