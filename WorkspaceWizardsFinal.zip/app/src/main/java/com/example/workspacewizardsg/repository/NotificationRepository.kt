package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.AppNotification
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

private const val MAX_SHOWN = 50
private const val MAX_STORED_LENGTH = 300

// The fields of one notification document. Shared with the transactions that send a
// notification together with another change, so every notification looks the same.
internal fun notificationData(audience: String, message: String, workOrderId: String?): Map<String, Any> {
    val data = mutableMapOf<String, Any>(
        "audience" to audience,
        "message" to message.take(MAX_STORED_LENGTH),
        "read" to false,
        "createdAt" to FieldValue.serverTimestamp()
    )
    if (workOrderId != null) data["workOrderId"] = workOrderId
    return data
}

class NotificationRepository {

    private val firestore = FirebaseFirestore.getInstance()
    private val collection = firestore.collection("notifications")

    // Real-time stream of one person's notifications, newest first
    fun observe(audience: String): Flow<List<AppNotification>> = callbackFlow {
        val listener = collection
            .whereEqualTo("audience", audience)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(
                    snapshot?.documents.orEmpty()
                        .map { it.toNotification() }
                        .sortedByDescending { it.createdAt }
                        .take(MAX_SHOWN)
                )
            }
        awaitClose { listener.remove() }
    }

    suspend fun send(audience: String, message: String, workOrderId: String? = null): Result<Unit> {
        return try {
            collection.add(notificationData(audience, message, workOrderId)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markRead(notificationIds: List<String>): Result<Unit> {
        if (notificationIds.isEmpty()) return Result.success(Unit)
        return try {
            val batch = firestore.batch()
            notificationIds.forEach { batch.update(collection.document(it), "read", true) }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ESTIMATE: a notification just written by this device shows its time straight away
    private fun DocumentSnapshot.toNotification() = AppNotification(
        notificationId = id,
        message = getString("message").orEmpty(),
        workOrderId = getString("workOrderId"),
        read = getBoolean("read") ?: false,
        createdAt = getTimestamp("createdAt", ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L
    )
}