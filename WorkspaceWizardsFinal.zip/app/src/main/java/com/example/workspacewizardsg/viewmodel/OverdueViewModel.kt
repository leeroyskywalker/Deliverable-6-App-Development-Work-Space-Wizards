package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.repository.WorkOrderRepository
import com.example.workspacewizardsg.util.isOverdue
import com.example.workspacewizardsg.util.overdueAlert
import kotlinx.coroutines.launch

// Tells the admin, once, about each job that has gone past its due date.
// No server does this (that would need Cloud Functions), so it runs whenever the admin's app
// is open: jobs that went overdue while it was closed are reported the next time it opens.
class OverdueViewModel(
    private val repository: WorkOrderRepository = WorkOrderRepository()
) : ViewModel() {

    // Jobs being reported right now, so two quick list updates can't report the same job twice
    private val inFlight = mutableSetOf<String>()

    fun escalate(orders: List<WorkOrder>) {
        orders
            .filter { isOverdue(it) && !it.overdueNotified && inFlight.add(it.workOrderId) }
            .forEach { order ->
                viewModelScope.launch {
                    // The repository checks again inside a transaction, so a stale list can't cause a repeat.
                    // If this fails (no connection) the job is tried again on the next list update.
                    repository.escalateOverdue(order.workOrderId, overdueAlert(order))
                    inFlight.remove(order.workOrderId)
                }
            }
    }
}