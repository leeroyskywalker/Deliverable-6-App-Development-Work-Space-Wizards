package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.repository.ClientRepository
import com.example.workspacewizardsg.repository.WorkOrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlinx.coroutines.flow.catch
import com.example.workspacewizardsg.util.sortDueSoonFirst

enum class WorkOrderFilter { ALL, PENDING, IN_PROGRESS, COMPLETED }

data class DashboardUiState(
    val allWorkOrders: List<WorkOrder> = emptyList(),
    val clients: List<Client> = emptyList(),
    val activeFilter: WorkOrderFilter = WorkOrderFilter.ALL,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class WorkOrderViewModel(
    private val workOrderRepository: WorkOrderRepository = WorkOrderRepository(),
    private val clientRepository: ClientRepository = ClientRepository()
) : ViewModel() {

    private val _filter = MutableStateFlow(WorkOrderFilter.ALL)
    private val _error = MutableStateFlow<String?>(null)
    private val _isLoading = MutableStateFlow(false)

    val uiState: StateFlow<DashboardUiState> = combine(
        workOrderRepository.observeAllWorkOrders().catch {emit(emptyList())},
        clientRepository.observeClients().catch {emit(emptyList())},
        _filter,
        _error,
        _isLoading
    ) { workOrders, clients, filter, error, loading ->
        DashboardUiState(
            allWorkOrders = workOrders,
            clients = clients,
            activeFilter = filter,
            isLoading = loading,
            errorMessage = error
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState(isLoading = true)
    )

    // Filtered list derived from current state — used directly in the UI
    fun filteredWorkOrders(state: DashboardUiState): List<WorkOrder> {
        return when (state.activeFilter) {
            WorkOrderFilter.ALL -> state.allWorkOrders
            WorkOrderFilter.PENDING -> state.allWorkOrders
                .filter { it.status == "PENDING" }
            WorkOrderFilter.IN_PROGRESS -> state.allWorkOrders
                .filter { it.status == "IN_PROGRESS" }
            WorkOrderFilter.COMPLETED -> state.allWorkOrders
                .filter { it.status == "COMPLETED" }
        }
    }

    fun setFilter(filter: WorkOrderFilter) {
        _filter.value = filter
    }

    fun createWorkOrder(workOrder: WorkOrder) {
        viewModelScope.launch {
            _isLoading.value = true
            workOrderRepository.createWorkOrder(workOrder).fold(
                onSuccess = { _error.value = null },
                onFailure = { _error.value = "Failed to create work order" }
            )
            _isLoading.value = false
        }
    }

    fun createWorkOrderWithNewClient(client: Client, workOrder: WorkOrder) {
        viewModelScope.launch {
            _isLoading.value = true
            workOrderRepository.createWorkOrderWithNewClient(client, workOrder).fold(
                onSuccess = { _error.value = null },
                onFailure = { _error.value = "Failed to create client and work order" }
            )
            _isLoading.value = false
        }
    }

    // Returns +27XXXXXXXXX (the format Twilio WhatsApp needs) or null if invalid
    fun normalisePhone(raw: String): String? {
        val cleaned = raw.filter { it.isDigit() || it == '+' }
        val e164 = when {
            cleaned.startsWith("+27") -> cleaned
            cleaned.startsWith("27") -> "+$cleaned"
            cleaned.startsWith("0") -> "+27" + cleaned.drop(1)
            else -> return null
        }
        return if (e164.matches(Regex("^\\+27\\d{9}$"))) e164 else null
    }

    fun clientExists(companyName: String, phone: String?, clients: List<Client>): Boolean =
        clients.any {
            it.companyName.trim().equals(companyName.trim(), ignoreCase = true) ||
                    (phone != null && normalisePhone(it.phone) == phone)
        }

    fun deleteWorkOrder(workOrderId: String) {
        viewModelScope.launch {
            workOrderRepository.deleteWorkOrder(workOrderId).fold(
                onSuccess = { _error.value = null },
                onFailure = { _error.value = "Failed to delete work order" }
            )
        }
    }

    fun clearError() { _error.value = null }

    // KPI helpers — called from UI with the current state
    fun activeJobCount(orders: List<WorkOrder>): Int =
        orders.count { it.status == "PENDING" || it.status == "IN_PROGRESS" }

    // Pending jobs due within two days (or overdue) come first, then everything else as before
    fun activeWorkOrders(orders: List<WorkOrder>): List<WorkOrder> =
        sortDueSoonFirst(orders.filter { it.status == "PENDING" || it.status == "IN_PROGRESS" })

    fun workOrdersByStatus(orders: List<WorkOrder>, status: String): List<WorkOrder> =
        orders.filter { it.status == status }

    fun completedTodayCount(orders: List<WorkOrder>): Int {
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return orders.count {
            it.status == "COMPLETED" && it.createdAt >= startOfDay
        }
    }
    fun greeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour < 12 -> "Good Morning"
            hour < 18 -> "Good Afternoon"
            else -> "Good Evening"
        }
    }

    fun unpaidInvoiceCount(orders: List<WorkOrder>): Int =
        orders.count { it.status == "COMPLETED" }

    fun monthlyRevenue(orders: List<WorkOrder>): Double {
        val startOfMonth = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        return orders
            .filter { it.status == "COMPLETED" && it.createdAt >= startOfMonth }
            .sumOf { it.amountZAR }
    }
}