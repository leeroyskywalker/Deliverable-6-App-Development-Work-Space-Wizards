package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.CrewMember
import com.example.workspacewizardsg.repository.AuthRepository
import com.example.workspacewizardsg.repository.CrewMemberRepository
import com.example.workspacewizardsg.util.crewMemberError
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TeamViewModel(
    private val repository: CrewMemberRepository = CrewMemberRepository(),
    authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val crewId: String? = authRepository.currentUser()?.uid

    // The signed-in crew's own members, A-Z. null = still loading
    val members: StateFlow<List<CrewMember>?> =
        (if (crewId == null) flowOf(emptyList()) else repository.observeMembers(crewId))
            .map { list -> list.sortedBy { it.firstName.lowercase() } }
            .catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    // editingId is the member being edited (null when adding)
    fun validateMember(editingId: String?, firstName: String, lastName: String): String? =
        crewMemberError(firstName, lastName, members.value.orEmpty(), editingId)

    // Call validateMember first
    fun addMember(firstName: String, lastName: String) {
        val id = crewId ?: return
        viewModelScope.launch {
            repository.addMember(
                CrewMember(crewId = id, firstName = firstName.trim(), lastName = lastName.trim())
            ).fold(
                onSuccess = { _message.value = "Team member added" },
                onFailure = { _message.value = "Could not add the member. Check your connection." }
            )
        }
    }

    // Call validateMember first
    fun updateMember(member: CrewMember, firstName: String, lastName: String) {
        viewModelScope.launch {
            repository.updateMember(member.memberId, firstName.trim(), lastName.trim()).fold(
                onSuccess = { _message.value = "Team member updated" },
                onFailure = { _message.value = "Could not save the changes. Check your connection." }
            )
        }
    }

    fun setAvailable(member: CrewMember, available: Boolean) {
        viewModelScope.launch {
            repository.setAvailable(member.memberId, available).onFailure {
                _message.value = "Could not update availability. Check your connection."
            }
        }
    }

    fun deleteMember(member: CrewMember) {
        viewModelScope.launch {
            repository.deleteMember(member.memberId).fold(
                onSuccess = { _message.value = "Team member removed" },
                onFailure = { _message.value = "Could not remove the member. Check your connection." }
            )
        }
    }

    fun clearMessage() { _message.value = null }
}