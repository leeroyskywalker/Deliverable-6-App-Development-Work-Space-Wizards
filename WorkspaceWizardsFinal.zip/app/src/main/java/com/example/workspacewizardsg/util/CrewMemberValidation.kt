package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.CrewMember

// First problem found with a member's name, or null when it is fine.
// editingId is the member being edited (null when adding), so a member never clashes with itself.
fun crewMemberError(
    firstName: String,
    lastName: String,
    existing: List<CrewMember>,
    editingId: String? = null
): String? {
    personNameError(firstName, "First name")?.let { return it }
    personNameError(lastName, "Surname")?.let { return it }
    val duplicate = existing.any {
        it.memberId != editingId &&
                it.firstName.trim().equals(firstName.trim(), ignoreCase = true) &&
                it.lastName.trim().equals(lastName.trim(), ignoreCase = true)
    }
    return if (duplicate) "A team member with this name already exists" else null
}