package com.example.workspacewizardsg.viewmodel

import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.repository.InvoiceRepository
import com.example.workspacewizardsg.repository.WorkOrderRepository
import com.example.workspacewizardsg.util.FinancialReport
import com.example.workspacewizardsg.util.buildFinancialReport
import com.example.workspacewizardsg.util.layoutReport
import com.example.workspacewizardsg.util.writeReportPdf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AnalyticsUiState(
    val isLoading: Boolean = true,
    val report: FinancialReport = FinancialReport(),
    val isSaving: Boolean = false,
    val message: String? = null,
    // Set once the PDF is saved, so the screen can offer to share it
    val savedPdf: Uri? = null
)

class AnalyticsViewModel(
    workOrderRepository: WorkOrderRepository = WorkOrderRepository(),
    invoiceRepository: InvoiceRepository = InvoiceRepository()
) : ViewModel() {

    private val _isSaving = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)
    private val _savedPdf = MutableStateFlow<Uri?>(null)

    val uiState: StateFlow<AnalyticsUiState> = combine(
        workOrderRepository.observeAllWorkOrders().catch { emit(emptyList()) },
        invoiceRepository.observeInvoices().catch { emit(emptyList()) },
        _isSaving,
        _message,
        _savedPdf
    ) { orders, invoices, saving, message, savedPdf ->
        AnalyticsUiState(
            isLoading = false,
            report = buildFinancialReport(orders, invoices),
            isSaving = saving,
            message = message,
            savedPdf = savedPdf
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AnalyticsUiState()
    )

    // Writes the summary PDF to the file the user picked. Painting pages is slow, so it runs off the main thread.
    fun savePdf(resolver: ContentResolver, uri: Uri) {
        if (_isSaving.value) return
        val report = uiState.value.report.copy(generatedAt = System.currentTimeMillis())
        viewModelScope.launch {
            _isSaving.value = true
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val stream = resolver.openOutputStream(uri) ?: error("Could not open the file")
                    stream.use { writeReportPdf(layoutReport(report), it) }
                }
            }
            result.fold(
                onSuccess = {
                    _savedPdf.value = uri
                    _message.value = "Financial summary saved"
                },
                onFailure = { _message.value = "Could not save the PDF. Please try again." }
            )
            _isSaving.value = false
        }
    }

    fun clearMessage() {
        _message.value = null
        _savedPdf.value = null
    }
}