package com.example.workspacewizardsg.uii

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.util.addressError
import com.example.workspacewizardsg.util.companyNameError
import com.example.workspacewizardsg.util.filterAndSortClients
import com.example.workspacewizardsg.util.personNameError
import com.example.workspacewizardsg.util.phoneError
import com.example.workspacewizardsg.util.toLocalPhone
import com.example.workspacewizardsg.viewmodel.ClientsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientsScreen(
    onNavigateBack: () -> Unit,
    onHome: () -> Unit,
    viewModel: ClientsViewModel = viewModel()
) {
    val clients by viewModel.clients.collectAsState()
    val message by viewModel.message.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()

    var query by rememberSaveable { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var editingClient by remember { mutableStateOf<Client?>(null) } // null = adding a new client
    var clientToDelete by remember { mutableStateOf<Client?>(null) }

    // Null while the first load is still running
    val visibleClients = clients?.let { filterAndSortClients(it, query) }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            AppTopBar(
                title = "Contact Directory",
                onBack = onNavigateBack,
                onHome = onHome,
                scrollBehavior = scrollBehavior
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        // One list for the whole page, so the button and search field scroll away with the contacts
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "add") {
                Button(
                    onClick = {
                        editingClient = null
                        showForm = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.padding(start = 6.dp))
                    Text("Add Contact")
                }
            }
            item(key = "search") {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search Contacts") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }
            when {
                visibleClients == null -> item(key = "loading") {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                visibleClients.isEmpty() -> item(key = "empty") {
                    if (query.isBlank()) {
                        EmptyState(
                            icon = Icons.Default.Person,
                            title = "No clients yet",
                            message = "Tap Add Contact to save your first client."
                        )
                    } else {
                        Text(
                            text = "No contacts match \"${query.trim()}\"",
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                else -> items(items = visibleClients, key = { it.clientId }) { client ->
                    ClientCard(
                        client = client,
                        onClick = {
                            editingClient = client
                            showForm = true
                        }
                    )
                }
            }
        }
    }

    if (showForm) {
        ClientFormDialog(
            existing = editingClient,
            validate = { company, contact, phone, address ->
                viewModel.validateClient(editingClient?.clientId, company, contact, phone, address)
            },
            onSave = { company, contact, phone, address ->
                viewModel.saveClient(editingClient, company, contact, phone, address)
                showForm = false
            },
            onDelete = editingClient?.let { client ->
                {
                    clientToDelete = client
                    showForm = false
                }
            },
            onDismiss = { showForm = false }
        )
    }

    clientToDelete?.let { client ->
        AlertDialog(
            onDismissRequest = { clientToDelete = null },
            title = { Text("Delete ${client.companyName}?") },
            text = { Text("This can't be undone. A client that still has work orders can't be deleted.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteClient(client)
                        clientToDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { clientToDelete = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ClientFormDialog(
    existing: Client?,
    validate: (company: String, contact: String, phone: String, address: String) -> String?,
    onSave: (company: String, contact: String, phone: String, address: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var company by remember { mutableStateOf(existing?.companyName.orEmpty()) }
    var contact by remember { mutableStateOf(existing?.contactPerson.orEmpty()) }
    // Saved numbers are +27..., but the form asks for the 10-digit local format
    var phone by remember { mutableStateOf(existing?.phone?.let { toLocalPhone(it) }.orEmpty()) }
    var address by remember { mutableStateOf(existing?.siteAddress.orEmpty()) }
    var duplicateProblem by remember { mutableStateOf<String?>(null) }
    var showErrors by remember { mutableStateOf(false) }

    val companyProblem = companyNameError(company)
    val contactProblem = personNameError(contact, "Contact person")
    val phoneProblem = phoneError(phone)
    val addressProblem = addressError(address)
    val hasProblems = listOf(companyProblem, contactProblem, phoneProblem, addressProblem)
        .any { it != null }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add Contact" else "Edit Contact") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (existing != null) {
                    Text(
                        text = "Changes don't affect existing jobs or invoices.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                ValidatedField(
                    value = company,
                    onValueChange = { company = it; duplicateProblem = null },
                    label = "Company name",
                    error = companyProblem,
                    showErrors = showErrors
                )
                ValidatedField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = "Contact person",
                    error = contactProblem,
                    showErrors = showErrors
                )
                ValidatedField(
                    value = phone,
                    onValueChange = { phone = it; duplicateProblem = null },
                    label = "Phone number (10 digits)",
                    error = phoneProblem,
                    showErrors = showErrors,
                    keyboardType = KeyboardType.Phone
                )
                ValidatedField(
                    value = address,
                    onValueChange = { address = it },
                    label = "Site address",
                    error = addressProblem,
                    showErrors = showErrors
                )
                duplicateProblem?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                if (onDelete != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text("Delete contact") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                showErrors = true
                if (hasProblems) return@TextButton
                // The field checks passed; this only catches a duplicate company name or phone
                val error = validate(company, contact, phone, address)
                if (error != null) duplicateProblem = error
                else onSave(company, contact, phone, address)
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// Also used by Global Search. Pass onClick to make the card tappable.
@Composable
internal fun ClientCard(client: Client, onClick: (() -> Unit)? = null) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = client.companyName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = client.contactPerson,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = client.phone,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = client.siteAddress,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}