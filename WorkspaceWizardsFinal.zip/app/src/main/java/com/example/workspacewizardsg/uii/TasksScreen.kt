package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.viewmodel.WorkOrderViewModel

private data class TaskSection(
    val status: String,
    val label: String,
    val orders: List<WorkOrder>
)

private val sectionOrder = listOf(
    "PENDING" to "Pending",
    "IN_PROGRESS" to "In Progress",
    "COMPLETED" to "Completed"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(
    onNavigateBack: () -> Unit,
    onHome: () -> Unit,
    onWorkOrderTapped: (workOrderId: String) -> Unit,
    viewModel: WorkOrderViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    val sections = sectionOrder.map { (status, label) ->
        TaskSection(status, label, viewModel.workOrdersByStatus(uiState.allWorkOrders, status))
    }

    Scaffold(
        topBar = { AppTopBar(title = "Tasks", onBack = onNavigateBack, onHome = onHome) }
    ) { innerPadding ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "summary") { StatusSummaryRow(sections) }

                sections.forEach { section ->
                    item(key = "header_${section.status}") {
                        SectionHeader(label = section.label, count = section.orders.size)
                    }
                    if (section.orders.isEmpty()) {
                        item(key = "empty_${section.status}") {
                            Text(
                                text = "No ${section.label.lowercase()} work orders",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(items = section.orders, key = { it.workOrderId }) { workOrder ->
                            WorkOrderCard(
                                workOrder = workOrder,
                                onClick = { onWorkOrderTapped(workOrder.workOrderId) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusSummaryRow(sections: List<TaskSection>) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        sections.forEach { section ->
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = section.orders.size.toString(),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    StatusBadge(status = section.status)
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(label: String, count: Int) {
    Text(
        text = "$label ($count)",
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        textAlign = TextAlign.Center,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
    )
}

