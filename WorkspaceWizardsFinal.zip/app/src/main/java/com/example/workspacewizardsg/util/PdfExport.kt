package com.example.workspacewizardsg.util

import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.OutputStream

// Paints the layout from ReportLayout.kt onto real PDF pages. Android's own PdfDocument, no library.
fun writeReportPdf(pages: List<List<DrawOp>>, out: OutputStream) {
    val document = PdfDocument()
    try {
        pages.forEachIndexed { index, ops ->
            val page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, index + 1).create())
            val canvas = page.canvas
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            ops.forEach { op ->
                when (op) {
                    is DrawOp.Rect -> {
                        paint.color = op.color
                        paint.style = Paint.Style.FILL
                        canvas.drawRect(op.x, op.y, op.x + op.w, op.y + op.h, paint)
                    }
                    is DrawOp.Line -> {
                        paint.color = op.color
                        paint.strokeWidth = 0.75f
                        canvas.drawLine(op.x1, op.y1, op.x2, op.y2, paint)
                    }
                    is DrawOp.Text -> {
                        paint.color = op.color
                        paint.style = Paint.Style.FILL
                        paint.textSize = op.size
                        paint.typeface = Typeface.create(Typeface.SANS_SERIF, if (op.bold) Typeface.BOLD else Typeface.NORMAL)
                        paint.textAlign = when (op.align) {
                            Align.LEFT -> Paint.Align.LEFT
                            Align.CENTER -> Paint.Align.CENTER
                            Align.RIGHT -> Paint.Align.RIGHT
                        }
                        canvas.drawText(op.text, op.x, op.y, paint)
                    }
                }
            }
            document.finishPage(page)
        }
        document.writeTo(out)
    } finally {
        document.close()
    }
}
