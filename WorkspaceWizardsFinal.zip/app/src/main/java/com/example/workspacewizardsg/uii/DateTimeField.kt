@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.workspacewizardsg.uii

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.workspacewizardsg.util.formatDateTime
import java.util.Calendar
import java.util.TimeZone

// Date and time picker for scheduling. Past days are greyed out and can't be selected.
// Step 1 picks the day, step 2 picks the time; the result is epoch milliseconds in local time.
@Composable
fun DateTimeField(
    label: String,
    valueMillis: Long?,
    onValueChange: (Long) -> Unit,
    error: String?,
    showErrors: Boolean,
    modifier: Modifier = Modifier
) {
    var showDatePicker by remember { mutableStateOf(false) }
    // Set when the day is confirmed; its presence opens the time step
    var pickedDayUtc by remember { mutableStateOf<Long?>(null) }
    val visibleError = if (showErrors || valueMillis != null) error else null

    Box(modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = valueMillis?.let { formatDateTime(it) }.orEmpty(),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            placeholder = { Text("Select date and time") },
            trailingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
            isError = visibleError != null,
            supportingText = if (visibleError != null) { { Text(visibleError) } } else null,
            modifier = Modifier.fillMaxWidth()
        )
        // A text field swallows taps, so a transparent layer on top opens the picker instead
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickable { showDatePicker = true }
        )
    }

    if (showDatePicker) {
        val dateState = rememberDatePickerState(
            // A past date can't be pre-selected because it isn't selectable
            initialSelectedDateMillis = valueMillis
                ?.let { localDayAsUtcMidnight(it) }
                ?.takeIf { it >= todayAsUtcMidnight() },
            selectableDates = FutureDatesOnly
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickedDayUtc = dateState.selectedDateMillis
                        showDatePicker = false
                    },
                    enabled = dateState.selectedDateMillis != null
                ) { Text("Next") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = dateState)
        }
    }

    pickedDayUtc?.let { dayUtc ->
        val current = Calendar.getInstance().apply {
            if (valueMillis != null) timeInMillis = valueMillis
            else {
                set(Calendar.HOUR_OF_DAY, 8)
                set(Calendar.MINUTE, 0)
            }
        }
        val timeState = rememberTimePickerState(
            initialHour = current.get(Calendar.HOUR_OF_DAY),
            initialMinute = current.get(Calendar.MINUTE),
            is24Hour = true
        )
        AlertDialog(
            onDismissRequest = { pickedDayUtc = null },
            title = { Text("Select time") },
            text = { TimePicker(state = timeState) },
            confirmButton = {
                TextButton(onClick = {
                    onValueChange(combineDayAndTime(dayUtc, timeState.hour, timeState.minute))
                    pickedDayUtc = null
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { pickedDayUtc = null }) { Text("Cancel") }
            }
        )
    }
}

private object FutureDatesOnly : SelectableDates {
    override fun isSelectableDate(utcTimeMillis: Long): Boolean =
        utcTimeMillis >= todayAsUtcMidnight()

    override fun isSelectableYear(year: Int): Boolean =
        year >= Calendar.getInstance().get(Calendar.YEAR)
}

// The Material3 DatePicker works in UTC midnights, so these convert to and from the
// device's local calendar day.
private fun todayAsUtcMidnight(): Long = localDayAsUtcMidnight(System.currentTimeMillis())

private fun localDayAsUtcMidnight(millis: Long): Long {
    val local = Calendar.getInstance().apply { timeInMillis = millis }
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(local.get(Calendar.YEAR), local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

private fun combineDayAndTime(dayUtcMidnight: Long, hour: Int, minute: Int): Long {
    val day = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = dayUtcMidnight }
    return Calendar.getInstance().apply {
        clear()
        set(day.get(Calendar.YEAR), day.get(Calendar.MONTH), day.get(Calendar.DAY_OF_MONTH), hour, minute, 0)
    }.timeInMillis
}