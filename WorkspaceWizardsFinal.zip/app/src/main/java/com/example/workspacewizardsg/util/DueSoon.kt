package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.WorkOrder
import java.util.Calendar

// A pending job is "due soon" when its scheduled day is today or within the next 2 days.
const val DUE_SOON_DAYS = 2

private const val DAY_MS = 24 * 60 * 60 * 1000.0

data class DueStatus(val label: String, val urgent: Boolean)

// A job that is not finished (waiting or in progress) is overdue once its scheduled day has passed.
// scheduledAt = 0 marks an older job that only has a free-text time, so it is ignored.
fun isOverdue(order: WorkOrder, now: Long = System.currentTimeMillis()): Boolean =
    order.status in OPEN_STATUSES && order.scheduledAt > 0L && daysUntilDue(order, now) < 0

// Overdue applies to every unfinished job. "Due today" and "Due soon" only apply to jobs nobody
// has started: one that is already in progress is not a worry until it is late.
fun dueStatus(order: WorkOrder, now: Long = System.currentTimeMillis()): DueStatus? {
    if (order.status !in OPEN_STATUSES || order.scheduledAt <= 0L) return null
    if (isOverdue(order, now)) return DueStatus("Overdue", urgent = true)
    if (order.status != "PENDING") return null
    val days = daysUntilDue(order, now)
    return when {
        days == 0 -> DueStatus("Due today", urgent = true)
        days == 1 -> DueStatus("Due tomorrow", urgent = false)
        days <= DUE_SOON_DAYS -> DueStatus("Due in $days days", urgent = false)
        else -> null
    }
}

// Due-soon and overdue jobs first (soonest first), everything else after in its existing order
fun sortDueSoonFirst(orders: List<WorkOrder>, now: Long = System.currentTimeMillis()): List<WorkOrder> {
    val (due, rest) = orders.partition { dueStatus(it, now) != null }
    return due.sortedBy { it.scheduledAt } + rest
}

// One short line per due or overdue job for the notification bell, soonest first
fun dueSoonMessages(orders: List<WorkOrder>, now: Long = System.currentTimeMillis()): List<String> =
    orders.mapNotNull { order -> dueStatus(order, now)?.let { order to it } }
        .sortedBy { (order, _) -> order.scheduledAt }
        .map { (order, due) -> "${due.label}: ${order.clientName}" }

// What the admin is told, once, when a job goes overdue
fun overdueAlert(order: WorkOrder): String =
    "Overdue: ${order.clientName} was due ${formatDateTime(order.scheduledAt)}"

// What the crew on a job is told when the admin moves its date
fun rescheduledAlert(order: WorkOrder, newScheduledAt: Long): String =
    "Rescheduled: ${order.clientName} is now due ${formatDateTime(newScheduledAt)}"

private val OPEN_STATUSES = setOf("PENDING", "IN_PROGRESS")

private fun daysUntilDue(order: WorkOrder, now: Long): Int =
    Math.round((startOfDay(order.scheduledAt) - startOfDay(now)) / DAY_MS).toInt()

private fun startOfDay(millis: Long): Long = Calendar.getInstance().apply {
    timeInMillis = millis
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis