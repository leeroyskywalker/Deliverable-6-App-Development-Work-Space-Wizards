package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.Invoice
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class InvoiceRepository(
    firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val invoices = firestore.collection("invoices")

    // Newest first. A malformed document is skipped instead of crashing the screen.
    fun observeInvoices(): Flow<List<Invoice>> = callbackFlow {
        val registration = invoices
            .orderBy("issuedDate", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents.orEmpty().mapNotNull { document ->
                    runCatching { document.toObject(Invoice::class.java) }.getOrNull()
                }
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun markAsPaid(invoiceId: String): Result<Unit> = runCatching {
        invoices.document(invoiceId)
            .update(
                mapOf(
                    "paymentStatus" to "PAID",
                    "paidAt" to System.currentTimeMillis()
                )
            )
            .await()
        Unit
    }
}