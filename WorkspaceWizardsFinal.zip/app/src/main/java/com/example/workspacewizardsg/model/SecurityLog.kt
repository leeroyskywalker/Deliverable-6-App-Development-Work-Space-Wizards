package com.example.workspacewizardsg.model

data class SecurityLog(
    val logId: String = "",
    val userId: String = "",
    val mfaType: String = "",
    val latencyMs: Long = 0,
    val success: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)