package com.example.workspacewizardsg.uii

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.CrewAccount
import com.example.workspacewizardsg.util.crewEmailError
import com.example.workspacewizardsg.util.crewNameError
import com.example.workspacewizardsg.util.messageError
import com.example.workspacewizardsg.util.passwordError
import com.example.workspacewizardsg.viewmodel.CrewRow
import com.example.workspacewizardsg.viewmodel.CrewsViewModel

// The admin's view of every crew: who is free, who is on a job, and how many team members can work.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrewsScreen(
    onBack: () -> Unit,
    onHome: () -> Unit,
    viewModel: CrewsViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()
    var showAddDialog by remember { mutableStateOf(false) }
    var messageTarget by remember { mutableStateOf<CrewAccount?>(null) }

    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = { AppTopBar(title = "Crews", onBack = onBack, onHome = onHome, scrollBehavior = scrollBehavior) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add crew") }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when {
                uiState.isLoading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                uiState.crews.isEmpty() -> EmptyState(
                    icon = Icons.Default.AccountCircle,
                    title = "No crews yet",
                    message = "Tap Add crew to create the first one.",
                    modifier = Modifier.align(Alignment.Center)
                )
                else -> LazyColumn(
                    // Bottom padding keeps the last card clear of the button
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "${uiState.crews.count { it.currentClient == null }} of " +
                                    "${uiState.crews.size} crews available",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(uiState.crews, key = { it.crew.userId }) { row ->
                        Box(modifier = Modifier.animateItem()) {
                            CrewCard(row = row, onMessage = { messageTarget = row.crew })
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddCrewDialog(
            existingNames = uiState.crews.map { it.crew.fullName },
            existingEmails = uiState.crews.map { it.crew.email },
            usedColours = uiState.crews.map { it.crew.teamColour.uppercase() },
            isBusy = uiState.isBusy,
            onAdd = { name, email, password, colour ->
                viewModel.addCrew(name, email, password, colour) { showAddDialog = false }
            },
            onDismiss = { showAddDialog = false }
        )
    }

    messageTarget?.let { crew ->
        MessageCrewDialog(
            crewName = crew.fullName,
            isBusy = uiState.isBusy,
            onSend = { text -> viewModel.messageCrew(crew, text) { messageTarget = null } },
            onDismiss = { messageTarget = null }
        )
    }
}

@Composable
private fun CrewCard(row: CrewRow, onMessage: () -> Unit) {
    val colour = parseTeamColour(row.crew.teamColour) ?: MaterialTheme.colorScheme.outline
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.height(IntrinsicSize.Min)) {
            Box(modifier = Modifier.width(8.dp).fillMaxHeight().background(colour))
            Column(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(row.crew.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = row.crew.email,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                AvailabilityChip(row.currentClient)
                Text(
                    text = if (row.membersTotal == 0) "No team members added yet"
                    else "${row.membersAvailable} of ${row.membersTotal} team members available",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(onClick = onMessage) { Text("Message") }
            }
        }
    }
}

@Composable
private fun AvailabilityChip(currentClient: String?) {
    val free = currentClient == null
    val colour = if (free) Color(0xFF2E7D32) else Color(0xFFEF6C00)
    Surface(color = colour.copy(alpha = 0.15f), shape = RoundedCornerShape(50)) {
        Text(
            text = if (free) "Available" else "On a job: $currentClient",
            style = MaterialTheme.typography.labelMedium,
            color = colour,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

// Team colours the admin can pick from. A colour already used by another crew can't be picked again.
private val TEAM_COLOURS = listOf(
    "#1E88E5", "#43A047", "#FB8C00", "#8E24AA",
    "#E53935", "#00897B", "#D81B60", "#FDD835"
)

@Composable
private fun AddCrewDialog(
    existingNames: List<String>,
    existingEmails: List<String>,
    usedColours: List<String>,
    isBusy: Boolean,
    onAdd: (name: String, email: String, password: String, colour: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var colour by remember { mutableStateOf<String?>(null) }
    var showErrors by remember { mutableStateOf(false) }

    val nameProblem = crewNameError(name, existingNames)
    val emailProblem = crewEmailError(email, existingEmails)
    val passwordProblem = passwordError(password)
    val colourProblem = if (colour == null) "Pick a team colour" else null
    val isValid = listOf(nameProblem, emailProblem, passwordProblem, colourProblem).all { it == null }

    AlertDialog(
        onDismissRequest = { if (!isBusy) onDismiss() },
        title = { Text("Add crew") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ValidatedField(name, { name = it }, "Crew name (e.g. Crew 3)", nameProblem, showErrors)
                ValidatedField(
                    value = email,
                    onValueChange = { email = it },
                    label = "Login email",
                    error = emailProblem,
                    showErrors = showErrors,
                    keyboardType = KeyboardType.Email
                )
                ValidatedField(password, { password = it }, "Starting password", passwordProblem, showErrors)
                Text(
                    text = "Team colour",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                TEAM_COLOURS.chunked(4).forEach { rowColours ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowColours.forEach { hex ->
                            ColourSwatch(
                                hex = hex,
                                selected = colour == hex,
                                taken = hex.uppercase() in usedColours,
                                onClick = { colour = hex }
                            )
                        }
                    }
                }
                if (showErrors && colourProblem != null) {
                    Text(colourProblem, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    showErrors = true
                    if (isValid) onAdd(name, email, password, colour!!)
                },
                enabled = !isBusy
            ) { Text(if (isBusy) "Adding..." else "Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !isBusy) { Text("Cancel") } }
    )
}

@Composable
private fun ColourSwatch(hex: String, selected: Boolean, taken: Boolean, onClick: () -> Unit) {
    val colour = parseTeamColour(hex) ?: return
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(40.dp)
            .alpha(if (taken) 0.3f else 1f)
            .background(colour, CircleShape)
            .clickable(enabled = !taken, onClick = onClick)
    ) {
        if (selected) {
            Icon(
                Icons.Default.Check,
                contentDescription = "Selected",
                tint = if (colour.luminance() > 0.5f) Color.Black else Color.White
            )
        }
    }
}

@Composable
private fun MessageCrewDialog(
    crewName: String,
    isBusy: Boolean,
    onSend: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    var showErrors by remember { mutableStateOf(false) }
    val problem = messageError(text)

    AlertDialog(
        onDismissRequest = { if (!isBusy) onDismiss() },
        title = { Text("Message $crewName") },
        text = {
            ValidatedField(
                value = text,
                onValueChange = { text = it },
                label = "Message",
                error = problem,
                showErrors = showErrors,
                singleLine = false,
                minLines = 3
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    showErrors = true
                    if (problem == null) onSend(text)
                },
                enabled = !isBusy
            ) { Text(if (isBusy) "Sending..." else "Send") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !isBusy) { Text("Cancel") } }
    )
}

