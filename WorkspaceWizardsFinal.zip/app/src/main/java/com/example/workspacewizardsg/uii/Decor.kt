package com.example.workspacewizardsg.uii

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.workspacewizardsg.R

// Shared look-and-feel pieces: the logo, the background pattern and the empty-state card.

@Composable
fun WizardLogo(size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.ic_ww_logo),
        contentDescription = "Workspace Wizards logo",
        modifier = modifier.size(size)
    )
}

private const val PATTERN_ALPHA = 0.08f

// A grid of dots in the brand colour that fades out towards the middle of the screen.
// It is drawn on top of the app but takes no touches and is faint enough not to hurt reading.
@Composable
fun PatternOverlay(modifier: Modifier = Modifier) {
    val dot = MaterialTheme.colorScheme.primary
    Canvas(modifier = modifier.fillMaxSize()) {
        drawDotGrid(dot, PATTERN_ALPHA, fadeEnd = size.height * 0.55f)
    }
}

// Faint dots for a green surface, strongest at the top edge and fading out towards the bottom.
// Put it right after the background so the dots sit behind the content:
// Modifier.background(green).dotGrid()
fun Modifier.dotGrid(color: Color = Color.White, startAlpha: Float = 0.14f): Modifier =
    drawBehind { drawDotGrid(color, startAlpha, fadeEnd = size.height) }

// Rows of dots, every other row shifted half a step. The dots fade to nothing at fadeEnd.
private fun DrawScope.drawDotGrid(color: Color, startAlpha: Float, fadeEnd: Float) {
    val step = 22.dp.toPx()
    val radius = 1.5.dp.toPx()
    var row = 0
    var y = step / 2
    while (y < fadeEnd) {
        val dot = color.copy(alpha = startAlpha * (1f - y / fadeEnd))
        var x = if (row % 2 == 0) step / 2 else step
        while (x < size.width) {
            drawCircle(color = dot, radius = radius, center = Offset(x, y))
            x += step
        }
        y += step * 0.75f
        row++
    }
}

// True on a phone held sideways (or any window under 480dp tall), the same limit Android's
// window size classes use for "compact height". Screens use it to give the content more room.
@Composable
fun isCompactHeight(): Boolean = LocalConfiguration.current.screenHeightDp < 480

// What a list shows when it has nothing in it: an icon, what it means and what to do next.
@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier
) {
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    val compact = isCompactHeight()
    AnimatedVisibility(
        visibleState = visible,
        enter = fadeIn(tween(400)) + slideInVertically(tween(400)) { it / 6 },
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(if (compact) 56.dp else 88.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(if (compact) 28.dp else 40.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(if (compact) 8.dp else 16.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

