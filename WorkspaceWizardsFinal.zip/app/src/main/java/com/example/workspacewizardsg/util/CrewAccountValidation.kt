package com.example.workspacewizardsg.util

const val MAX_MESSAGE_LENGTH = 200

// existingNames: the other crews' names, so two crews can't share one
fun crewNameError(raw: String, existingNames: List<String>): String? {
    val name = raw.trim()
    return when {
        name.isEmpty() -> "Crew name is required"
        name.length < 2 -> "Crew name is too short"
        name.length > 30 -> "Crew name is too long (30 characters max)"
        name.none { it.isLetter() } -> "Crew name must contain letters"
        !name.all { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '\'' } ->
            "Use letters, numbers, spaces and hyphens only"
        existingNames.any { it.trim().equals(name, ignoreCase = true) } ->
            "A crew with this name already exists"
        else -> null
    }
}

fun crewEmailError(raw: String, existingEmails: List<String>): String? =
    emailError(raw) ?: if (existingEmails.any { it.trim().equals(raw.trim(), ignoreCase = true) })
        "A crew with this email already exists" else null

fun passwordError(raw: String): String? = when {
    raw.isEmpty() -> "Password is required"
    raw.length < 8 -> "Use at least 8 characters"
    raw.any { it.isWhitespace() } -> "Password can't contain spaces"
    raw.none { it.isLetter() } || raw.none { it.isDigit() } -> "Use both letters and numbers"
    else -> null
}

fun messageError(raw: String): String? {
    val text = raw.trim()
    return when {
        text.isEmpty() -> "Write a message"
        text.length > MAX_MESSAGE_LENGTH -> "Message is too long ($MAX_MESSAGE_LENGTH characters max)"
        else -> null
    }
}

