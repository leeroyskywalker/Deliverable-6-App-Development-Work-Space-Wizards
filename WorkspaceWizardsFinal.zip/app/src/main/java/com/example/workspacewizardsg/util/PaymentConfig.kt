package com.example.workspacewizardsg.util

object PaymentConfig {
    const val ACCOUNT_HOLDER = "Workspace Wizards"
    const val BANK_NAME = "Standard Bank"
    const val ACCOUNT_NUMBER = "4829 4382 5833 4392"
    const val BRANCH_CODE = "13382"
}