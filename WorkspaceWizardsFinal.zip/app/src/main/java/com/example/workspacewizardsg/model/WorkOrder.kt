package com.example.workspacewizardsg.model

data class WorkOrder(
    val workOrderId: String = "",
    val clientId: String = "",
    val clientName: String = "",
    val contactPerson: String = "",     // copied from the client when the job is created
    val clientPhone: String = "",
    val siteAddress: String = "",
    val serviceDetails: String = "",
    val amountZAR: Double = 0.0,
    val scheduledTime: String = "",     // readable text of the scheduled date, kept for older screens
    val scheduledAt: Long = 0L,         // the real scheduled date; 0 = older job with text only
    val status: String = "PENDING",
    val assignedCrew: String? = null,
    val assignedCrewName: String? = null,
    val teamColour: String? = null,
    // Written by the server clock when the crew takes each step; 0 = not happened yet
    val claimedAt: Long = 0L,
    val onTheWayAt: Long = 0L,
    val startedAt: Long = 0L,
    val completedAt: Long = 0L,
    val teamMembers: List<String> = emptyList(),   // names of who worked the job, saved when it starts
    val overdueNotified: Boolean = false,          // the admin has been told this job is overdue
    val rescheduleCount: Int = 0,                  // how many times the admin moved the date
    val createdAt: Long = System.currentTimeMillis()
)