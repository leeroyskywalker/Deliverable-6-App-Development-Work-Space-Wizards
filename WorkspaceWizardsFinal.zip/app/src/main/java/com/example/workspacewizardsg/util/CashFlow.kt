package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.WorkOrder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class MonthRevenue(val label: String, val amount: Double)

// Revenue = the total of all completed work orders.
fun completedRevenue(orders: List<WorkOrder>): Double =
    orders.filter { it.status == "COMPLETED" }.sumOf { it.amountZAR }

// Completed revenue for each of the last `months` calendar months, oldest first.
// A job counts in the month it was completed (older jobs without that time use the month they were added).
fun revenueByMonth(
    orders: List<WorkOrder>,
    months: Int = 6,
    now: Long = System.currentTimeMillis()
): List<MonthRevenue> {
    val completed = orders.filter { it.status == "COMPLETED" }
    val labelFormat = SimpleDateFormat("MMM", Locale.getDefault())

    return ((months - 1) downTo 0).map { monthsAgo ->
        val start = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.MONTH, -monthsAgo)
        }
        val end = (start.clone() as Calendar).apply { add(Calendar.MONTH, 1) }

        MonthRevenue(
            label = labelFormat.format(start.time),
            amount = completed
                .filter { (if (it.completedAt > 0) it.completedAt else it.createdAt) in start.timeInMillis until end.timeInMillis }
                .sumOf { it.amountZAR }
        )
    }
}