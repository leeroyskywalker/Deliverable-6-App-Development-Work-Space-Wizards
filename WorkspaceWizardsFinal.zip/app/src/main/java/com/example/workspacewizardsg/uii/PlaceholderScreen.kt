package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

// Temporary screen so every menu item has a page to open. Each one is replaced by its real screen later.
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaceholderScreen(title: String, onBack: () -> Unit, onHome: () -> Unit) {
    Scaffold(topBar = { AppTopBar(title = title, onBack = onBack, onHome = onHome) }) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$title is coming soon",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
