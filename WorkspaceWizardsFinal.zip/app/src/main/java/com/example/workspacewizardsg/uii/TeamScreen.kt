package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.workspacewizardsg.model.CrewMember
import com.example.workspacewizardsg.model.fullName
import com.example.workspacewizardsg.util.personNameError
import com.example.workspacewizardsg.viewmodel.TeamViewModel

// The crew leader's team: add, edit and remove members and mark who is available.
// Shown as a tab of the crew screen, so it has no top bar of its own.
@Composable
fun TeamScreen(
    snackbarHostState: SnackbarHostState,
    viewModel: TeamViewModel
) {
    val members by viewModel.members.collectAsState()
    val message by viewModel.message.collectAsState()

    var showForm by remember { mutableStateOf(false) }
    var editingMember by remember { mutableStateOf<CrewMember?>(null) } // null = adding a new member
    var memberToDelete by remember { mutableStateOf<CrewMember?>(null) }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val list = members
    // One list for the whole tab, so the Add button scrolls away with the members
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "add") {
            Button(
                onClick = {
                    editingMember = null
                    showForm = true
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.padding(start = 6.dp))
                Text("Add Team Member")
            }
        }
        when {
            list == null -> item(key = "loading") {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            list.isEmpty() -> item(key = "empty") {
                EmptyState(
                    icon = Icons.Default.Person,
                    title = "No team members yet",
                    message = "Add at least one so you can start jobs."
                )
            }

            else -> {
                item(key = "summary") {
                    Text(
                        text = "${list.count { it.available }} of ${list.size} available",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items(items = list, key = { it.memberId }) { member ->
                    Box(modifier = Modifier.animateItem()) {
                        MemberCard(
                            member = member,
                            onClick = {
                                editingMember = member
                                showForm = true
                            },
                            onAvailableChange = { viewModel.setAvailable(member, it) }
                        )
                    }
                }
            }
        }
    }

    if (showForm) {
        MemberFormDialog(
            existing = editingMember,
            validate = { first, last ->
                viewModel.validateMember(editingMember?.memberId, first, last)
            },
            onSave = { first, last ->
                val member = editingMember
                if (member == null) viewModel.addMember(first, last)
                else viewModel.updateMember(member, first, last)
                showForm = false
            },
            onDelete = editingMember?.let { member ->
                {
                    memberToDelete = member
                    showForm = false
                }
            },
            onDismiss = { showForm = false }
        )
    }

    memberToDelete?.let { member ->
        AlertDialog(
            onDismissRequest = { memberToDelete = null },
            title = { Text("Remove ${member.fullName}?") },
            text = { Text("Past jobs keep their name in the history.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteMember(member)
                        memberToDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { memberToDelete = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun MemberCard(
    member: CrewMember,
    onClick: () -> Unit,
    onAvailableChange: (Boolean) -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = member.fullName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = if (member.available) "Available" else "Unavailable",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (member.available) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = member.available, onCheckedChange = onAvailableChange)
        }
    }
}

@Composable
private fun MemberFormDialog(
    existing: CrewMember?,
    validate: (first: String, last: String) -> String?,
    onSave: (first: String, last: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var firstName by remember { mutableStateOf(existing?.firstName.orEmpty()) }
    var lastName by remember { mutableStateOf(existing?.lastName.orEmpty()) }
    var duplicateProblem by remember { mutableStateOf<String?>(null) }
    var showErrors by remember { mutableStateOf(false) }

    val firstProblem = personNameError(firstName, "First name")
    val lastProblem = personNameError(lastName, "Surname")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add Team Member" else "Edit Team Member") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ValidatedField(
                    value = firstName,
                    onValueChange = { firstName = it; duplicateProblem = null },
                    label = "First name",
                    error = firstProblem,
                    showErrors = showErrors
                )
                ValidatedField(
                    value = lastName,
                    onValueChange = { lastName = it; duplicateProblem = null },
                    label = "Surname",
                    error = lastProblem,
                    showErrors = showErrors
                )
                duplicateProblem?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                if (onDelete != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) { Text("Remove team member") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                showErrors = true
                if (firstProblem != null || lastProblem != null) return@TextButton
                // Field checks passed; this only catches a duplicate name
                val error = validate(firstName, lastName)
                if (error != null) duplicateProblem = error
                else onSave(firstName, lastName)
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}