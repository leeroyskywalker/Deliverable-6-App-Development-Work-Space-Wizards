package com.example.workspacewizardsg.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// The financial summary as drawing instructions on A4 pages (units are PDF points).
// Kept free of Android so the layout can be unit tested; PdfExport.kt only paints these.

const val PAGE_WIDTH = 595
const val PAGE_HEIGHT = 842

enum class Align { LEFT, CENTER, RIGHT }

sealed class DrawOp {
    data class Text(
        val x: Float, val y: Float, val text: String, val size: Float,
        val bold: Boolean = false, val align: Align = Align.LEFT, val color: Int = INK
    ) : DrawOp()
    data class Rect(val x: Float, val y: Float, val w: Float, val h: Float, val color: Int) : DrawOp()
    data class Line(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val color: Int) : DrawOp()
}

private const val MARGIN = 40f
private const val CONTENT_WIDTH = PAGE_WIDTH - 2 * MARGIN
private const val BOTTOM = PAGE_HEIGHT - 60f   // table rows stop here; the footer sits below
private const val ROW_HEIGHT = 18f
private const val CONTINUED_TOP = 60f

private const val TEAL = 0xFF006D77.toInt()
private const val INK = 0xFF1C2733.toInt()
private const val GREY = 0xFF5D6B79.toInt()
private const val LIGHT = 0xFFEEF2F5.toInt()
private const val RULE = 0xFFD9E1E8.toInt()
private const val WHITE = 0xFFFFFFFF.toInt()
private const val GREEN = 0xFF2E7D32.toInt()
private const val ORANGE = 0xFFEF6C00.toInt()

// South African style: R 12 345.00
fun formatRand(amount: Double): String =
    "R " + String.format(Locale.US, "%,.2f", amount).replace(',', ' ')

fun compactRand(amount: Double): String = when {
    amount >= 1_000_000 -> "R%.1fM".format(Locale.US, amount / 1_000_000)
    amount >= 1_000 -> "R%.1fk".format(Locale.US, amount / 1_000)
    else -> "R%.0f".format(Locale.US, amount)
}

fun ellipsize(text: String, maxChars: Int): String =
    if (text.length <= maxChars) text else text.take(maxChars - 1).trimEnd() + "…"

fun layoutReport(report: FinancialReport): List<List<DrawOp>> {
    val pages = mutableListOf<MutableList<DrawOp>>()
    var ops = mutableListOf<DrawOp>().also { pages += it }

    drawHeader(ops, report)
    drawFigures(ops, report)
    drawChart(ops, report)

    var y = 395f
    ops += DrawOp.Text(MARGIN, y, "Invoices", 12f, bold = true, color = INK)
    y += 12f
    drawTableHeader(ops, y)
    y += ROW_HEIGHT

    if (report.invoices.isEmpty()) {
        ops += DrawOp.Text(MARGIN, y + 14f, "No invoices yet", 9f, color = GREY)
    }
    report.invoices.forEach { line ->
        if (y + ROW_HEIGHT > BOTTOM) {
            ops = mutableListOf<DrawOp>().also { pages += it }
            y = CONTINUED_TOP
            ops += DrawOp.Text(MARGIN, y, "Invoices (continued)", 12f, bold = true, color = INK)
            y += 12f
            drawTableHeader(ops, y)
            y += ROW_HEIGHT
        }
        drawInvoiceRow(ops, y, line)
        y += ROW_HEIGHT
    }

    pages.forEachIndexed { index, page ->
        page += DrawOp.Text(
            PAGE_WIDTH / 2f, PAGE_HEIGHT - 28f, "Page ${index + 1} of ${pages.size}",
            8f, align = Align.CENTER, color = GREY
        )
    }
    return pages
}

private fun drawHeader(ops: MutableList<DrawOp>, report: FinancialReport) {
    ops += DrawOp.Rect(0f, 0f, PAGE_WIDTH.toFloat(), 84f, TEAL)
    ops += DrawOp.Text(MARGIN, 40f, "Workspace Wizards", 20f, bold = true, color = WHITE)
    ops += DrawOp.Text(MARGIN, 62f, "Financial Summary", 12f, color = WHITE)
    val date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(report.generatedAt))
    ops += DrawOp.Text(PAGE_WIDTH - MARGIN, 62f, "Generated $date", 10f, align = Align.RIGHT, color = WHITE)
}

private fun drawFigures(ops: MutableList<DrawOp>, report: FinancialReport) {
    val gap = 10f
    val width = (CONTENT_WIDTH - 3 * gap) / 4
    val top = 108f
    fun jobs(n: Int, word: String) = "$n $word invoice${if (n == 1) "" else "s"}"
    val tiles = listOf(
        Triple("Revenue", formatRand(report.revenue), "${report.completedJobs} completed job${if (report.completedJobs == 1) "" else "s"}"),
        Triple("Collected", formatRand(report.collected), jobs(report.collectedCount, "paid")),
        Triple("Outstanding", formatRand(report.outstanding), jobs(report.outstandingCount, "unpaid")),
        Triple("Invoices", report.invoices.size.toString(), "issued in total")
    )
    tiles.forEachIndexed { i, (label, value, caption) ->
        val x = MARGIN + i * (width + gap)
        ops += DrawOp.Rect(x, top, width, 62f, LIGHT)
        ops += DrawOp.Text(x + 8f, top + 16f, label, 8.5f, color = GREY)
        ops += DrawOp.Text(x + 8f, top + 38f, value, 12.5f, bold = true, color = INK)
        ops += DrawOp.Text(x + 8f, top + 53f, caption, 8f, color = GREY)
    }
}

private fun drawChart(ops: MutableList<DrawOp>, report: FinancialReport) {
    ops += DrawOp.Text(MARGIN, 205f, "Revenue by month", 12f, bold = true, color = INK)
    val baseline = 340f
    val maxBar = 95f
    val max = report.months.maxOfOrNull { it.amount } ?: 0.0
    if (max <= 0.0) {
        ops += DrawOp.Text(PAGE_WIDTH / 2f, 285f, "No completed jobs yet", 9f, align = Align.CENTER, color = GREY)
        return
    }
    val slot = CONTENT_WIDTH / report.months.size
    report.months.forEachIndexed { i, month ->
        val centre = MARGIN + slot * i + slot / 2
        val height = if (month.amount > 0) (month.amount / max * maxBar).toFloat().coerceAtLeast(3f) else 0f
        if (height > 0f) ops += DrawOp.Rect(centre - 20f, baseline - height, 40f, height, TEAL)
        ops += DrawOp.Text(centre, baseline - height - 5f, compactRand(month.amount), 8f, align = Align.CENTER, color = GREY)
        ops += DrawOp.Text(centre, baseline + 14f, month.label, 9f, align = Align.CENTER, color = INK)
    }
    ops += DrawOp.Line(MARGIN, baseline, PAGE_WIDTH - MARGIN, baseline, RULE)
}

private fun drawTableHeader(ops: MutableList<DrawOp>, y: Float) {
    ops += DrawOp.Rect(MARGIN, y, CONTENT_WIDTH, ROW_HEIGHT, LIGHT)
    val baseline = y + 12.5f
    ops += DrawOp.Text(MARGIN + 6f, baseline, "Invoice", 8.5f, bold = true, color = GREY)
    ops += DrawOp.Text(MARGIN + 80f, baseline, "Client", 8.5f, bold = true, color = GREY)
    ops += DrawOp.Text(MARGIN + 300f, baseline, "Issued", 8.5f, bold = true, color = GREY)
    ops += DrawOp.Text(MARGIN + 375f, baseline, "Status", 8.5f, bold = true, color = GREY)
    ops += DrawOp.Text(PAGE_WIDTH - MARGIN - 6f, baseline, "Amount", 8.5f, bold = true, align = Align.RIGHT, color = GREY)
}

private fun drawInvoiceRow(ops: MutableList<DrawOp>, y: Float, line: InvoiceLine) {
    val baseline = y + 12.5f
    ops += DrawOp.Text(MARGIN + 6f, baseline, line.number, 9f, color = INK)
    ops += DrawOp.Text(MARGIN + 80f, baseline, ellipsize(line.client, 40), 9f, color = INK)
    ops += DrawOp.Text(
        MARGIN + 300f, baseline,
        if (line.issued > 0) SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(line.issued)) else "-",
        9f, color = INK
    )
    ops += DrawOp.Text(
        MARGIN + 375f, baseline, if (line.paid) "Paid" else "Unpaid", 9f,
        bold = true, color = if (line.paid) GREEN else ORANGE
    )
    ops += DrawOp.Text(PAGE_WIDTH - MARGIN - 6f, baseline, formatRand(line.amount), 9f, align = Align.RIGHT, color = INK)
    ops += DrawOp.Line(MARGIN, y + ROW_HEIGHT, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, RULE)
}

