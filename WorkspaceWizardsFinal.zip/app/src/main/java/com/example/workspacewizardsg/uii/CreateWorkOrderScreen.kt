package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.util.addressError
import com.example.workspacewizardsg.util.amountError
import com.example.workspacewizardsg.util.companyNameError
import com.example.workspacewizardsg.util.formatDateTime
import com.example.workspacewizardsg.util.personNameError
import com.example.workspacewizardsg.util.phoneError
import com.example.workspacewizardsg.util.scheduledError
import com.example.workspacewizardsg.util.serviceDetailsError
import com.example.workspacewizardsg.viewmodel.WorkOrderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateWorkOrderScreen(
    onNavigateBack: () -> Unit,
    viewModel: WorkOrderViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    var selectedClient by remember { mutableStateOf<Client?>(null) }
    var isNewClient by remember { mutableStateOf(false) }
    var newCompany by remember { mutableStateOf("") }
    var newContact by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newAddress by remember { mutableStateOf("") }
    var serviceDetails by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf("") }
    var scheduledAt by remember { mutableStateOf<Long?>(null) }
    var clientDropdownExpanded by remember { mutableStateOf(false) }

    // Messages stay hidden until the user types in a field or presses Create (see ValidatedField)
    var showErrors by remember { mutableStateOf(false) }
    var duplicateProblem by remember { mutableStateOf<String?>(null) }

    val clientProblem =
        if (!isNewClient && selectedClient == null) "Select a client or add a new one" else null
    val companyProblem = if (isNewClient) companyNameError(newCompany) else null
    val contactProblem = if (isNewClient) personNameError(newContact, "Contact person") else null
    val phoneProblem = if (isNewClient) phoneError(newPhone) else null
    val addressProblem = if (isNewClient) addressError(newAddress) else null
    val detailsProblem = serviceDetailsError(serviceDetails)
    val amountProblem = amountError(amountInput)
    val scheduleProblem = scheduledError(scheduledAt)

    val isValid = listOf(
        clientProblem, companyProblem, contactProblem, phoneProblem, addressProblem,
        detailsProblem, amountProblem, scheduleProblem
    ).all { it == null }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("New Work Order") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Client picker
            ExposedDropdownMenuBox(
                expanded = clientDropdownExpanded,
                onExpandedChange = { clientDropdownExpanded = it }
            ) {
                OutlinedTextField(
                    value = if (isNewClient) "New Client" else selectedClient?.companyName ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Client") },
                    placeholder = { Text("Select a client") },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = clientDropdownExpanded)
                    },
                    isError = showErrors && clientProblem != null,
                    supportingText = if (showErrors && clientProblem != null) {
                        { Text(clientProblem) }
                    } else null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )

                ExposedDropdownMenu(
                    expanded = clientDropdownExpanded,
                    onDismissRequest = { clientDropdownExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("+ New client") },
                        onClick = {
                            isNewClient = true
                            selectedClient = null
                            clientDropdownExpanded = false
                            duplicateProblem = null
                        }
                    )
                    if (uiState.clients.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("No clients found") },
                            onClick = { clientDropdownExpanded = false }
                        )
                    } else {
                        uiState.clients.forEach { client ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(client.companyName)
                                        Text(
                                            text = client.siteAddress,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    selectedClient = client
                                    isNewClient = false
                                    clientDropdownExpanded = false
                                    duplicateProblem = null
                                }
                            )
                        }
                    }
                }
            }

            if (isNewClient) {
                ValidatedField(
                    value = newCompany,
                    onValueChange = { newCompany = it; duplicateProblem = null },
                    label = "Company name",
                    error = companyProblem,
                    showErrors = showErrors
                )
                ValidatedField(
                    value = newContact,
                    onValueChange = { newContact = it },
                    label = "Contact person",
                    error = contactProblem,
                    showErrors = showErrors
                )
                ValidatedField(
                    value = newPhone,
                    onValueChange = { newPhone = it; duplicateProblem = null },
                    label = "Phone (10 digits, e.g. 082 123 4567)",
                    error = phoneProblem,
                    showErrors = showErrors,
                    keyboardType = KeyboardType.Phone
                )
                ValidatedField(
                    value = newAddress,
                    onValueChange = { newAddress = it },
                    label = "Site address",
                    error = addressProblem,
                    showErrors = showErrors
                )
            }

            // Selected client info — shown once a client is picked
            selectedClient?.let { client ->
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.medium
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = client.contactPerson,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = client.phone,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = client.siteAddress,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            ValidatedField(
                value = serviceDetails,
                onValueChange = { serviceDetails = it },
                label = "Service details",
                placeholder = "Describe the job",
                error = detailsProblem,
                showErrors = showErrors,
                singleLine = false,
                minLines = 3
            )

            ValidatedField(
                value = amountInput,
                onValueChange = {
                    if (it.isEmpty() || it.matches(Regex("^\\d*\\.?\\d{0,2}$"))) amountInput = it
                },
                label = "Amount (ZAR)",
                placeholder = "0.00",
                error = amountProblem,
                showErrors = showErrors,
                keyboardType = KeyboardType.Decimal,
                prefix = { Text("R ") }
            )

            DateTimeField(
                label = "Scheduled date & time",
                valueMillis = scheduledAt,
                onValueChange = { scheduledAt = it },
                error = scheduleProblem,
                showErrors = showErrors
            )

            duplicateProblem?.let {
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Button(
                onClick = {
                    showErrors = true
                    if (!isValid) return@Button

                    val whenMillis = scheduledAt ?: return@Button
                    val amount = amountInput.toDoubleOrNull() ?: return@Button
                    val phone = viewModel.normalisePhone(newPhone)

                    if (isNewClient && viewModel.clientExists(newCompany, phone, uiState.clients)) {
                        duplicateProblem = "This client already exists - pick them from the list"
                        return@Button
                    }

                    val target = selectedClient ?: Client(
                        companyName = newCompany.trim(),
                        contactPerson = newContact.trim(),
                        phone = phone ?: "",
                        siteAddress = newAddress.trim()
                    )
                    val order = WorkOrder(
                        clientId = target.clientId,
                        clientName = target.companyName,
                        contactPerson = target.contactPerson,
                        clientPhone = target.phone,
                        siteAddress = target.siteAddress,
                        serviceDetails = serviceDetails.trim(),
                        amountZAR = amount,
                        // scheduledTime stays as readable text so existing screens keep working;
                        // scheduledAt is the real date used for sorting and due-soon alerts
                        scheduledTime = formatDateTime(whenMillis),
                        scheduledAt = whenMillis
                    )
                    if (isNewClient) viewModel.createWorkOrderWithNewClient(target, order)
                    else viewModel.createWorkOrder(order)
                    onNavigateBack()
                },
                enabled = !uiState.isLoading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create Work Order")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
