package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.ADMIN_AUDIENCE
import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.model.Invoice
import com.example.workspacewizardsg.model.WorkOrder
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

enum class ClaimOutcome { CLAIMED, JOB_UNAVAILABLE, CREW_BUSY }

class WorkOrderRepository {

    private val workOrdersCollection = FirebaseFirestore
        .getInstance().collection("workOrders")
    private val firestore = FirebaseFirestore.getInstance()
    private val usersCollection = firestore.collection("users")
    private val invoicesCollection = firestore.collection("invoices")
    private val countersCollection = firestore.collection("counters")
    private val notificationsCollection = firestore.collection("notifications")

    // Real-time stream of all work orders, newest first
    fun observeAllWorkOrders(): Flow<List<WorkOrder>> = callbackFlow {
        val listener = workOrdersCollection
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.documents?.mapNotNull { it.toWorkOrder() } ?: emptyList())
            }
        awaitClose { listener.remove() }
    }

    fun observeWorkOrder(workOrderId: String): Flow<WorkOrder?> = callbackFlow {
        val listener = workOrdersCollection.document(workOrderId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.takeIf { it.exists() }?.toWorkOrder())
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateWorkOrderDetails(
        workOrderId: String,
        siteAddress: String,
        serviceDetails: String,
        amountZAR: Double,
        scheduledTime: String,
        scheduledAt: Long
    ): Result<Unit> {
        return try {
            val problem = firestore.runTransaction<String?> { tx ->
                val ref = workOrdersCollection.document(workOrderId)
                val order = tx.get(ref)
                if (!order.exists()) return@runTransaction "This work order no longer exists"
                if (order.getString("status") == "COMPLETED") {
                    return@runTransaction "This job is already completed and can't be edited"
                }
                tx.update(
                    ref, mapOf(
                        "siteAddress" to siteAddress,
                        "serviceDetails" to serviceDetails,
                        "amountZAR" to amountZAR,
                        "scheduledTime" to scheduledTime,
                        "scheduledAt" to scheduledAt
                    )
                )
                null
            }.await()
            if (problem == null) Result.success(Unit)
            else Result.failure(IllegalStateException(problem))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Moves an unfinished job to a new date. The overdue alert is re-armed for the new date, and the
    // crew holding the job (if any) is told in the same transaction.
    suspend fun rescheduleWorkOrder(
        workOrderId: String,
        scheduledAt: Long,
        scheduledTime: String,
        crewAlert: String
    ): Result<Unit> {
        return try {
            val problem = firestore.runTransaction<String?> { tx ->
                val ref = workOrdersCollection.document(workOrderId)
                val order = tx.get(ref)
                if (!order.exists()) return@runTransaction "This work order no longer exists"
                if (order.getString("status") == "COMPLETED") {
                    return@runTransaction "This job is already completed and can't be rescheduled"
                }
                tx.update(
                    ref, mapOf(
                        "scheduledAt" to scheduledAt,
                        "scheduledTime" to scheduledTime,
                        "overdueNotified" to false,
                        "rescheduleCount" to (order.getLong("rescheduleCount") ?: 0L) + 1
                    )
                )
                order.getString("assignedCrew")?.let { crew ->
                    tx.set(notificationsCollection.document(), notificationData(crew, crewAlert, workOrderId))
                }
                null
            }.await()
            if (problem == null) Result.success(Unit)
            else Result.failure(IllegalStateException(problem))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Marks an overdue job as reported and tells the admin, in one transaction, so the alert is
    // sent once even if two devices notice at the same moment. Returns true if this call sent it.
    suspend fun escalateOverdue(workOrderId: String, alert: String): Result<Boolean> {
        return try {
            val sent = firestore.runTransaction<Boolean> { tx ->
                val ref = workOrdersCollection.document(workOrderId)
                val order = tx.get(ref)
                val status = order.getString("status").orEmpty()
                val unfinished = status == "PENDING" || status == "IN_PROGRESS"
                if (!order.exists() || !unfinished || order.getBoolean("overdueNotified") == true) {
                    return@runTransaction false
                }
                tx.update(ref, "overdueNotified", true)
                tx.set(notificationsCollection.document(), notificationData(ADMIN_AUDIENCE, alert, workOrderId))
                true
            }.await()
            Result.success(sent)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createWorkOrder(workOrder: WorkOrder): Result<String> {
        return try {
            val docRef = workOrdersCollection.add(workOrder).await()
            workOrdersCollection.document(docRef.id)
                .update("workOrderId", docRef.id).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteWorkOrder(workOrderId: String): Result<Unit> {
        return try {
            val problem = firestore.runTransaction<String?> { tx ->
                val orderRef = workOrdersCollection.document(workOrderId)
                val order = tx.get(orderRef)
                if (!order.exists()) return@runTransaction null // already gone

                val status = order.getString("status")
                if (status == "COMPLETED") return@runTransaction "Completed jobs can't be deleted"

                // Reads first, then writes: Firestore requires this order in a transaction
                var crewRef: DocumentReference? = null
                var crewSnapshot: DocumentSnapshot? = null
                val crewId = order.getString("assignedCrew")
                if (status == "IN_PROGRESS" && !crewId.isNullOrBlank()) {
                    crewRef = usersCollection.document(crewId)
                    crewSnapshot = tx.get(crewRef)
                }

                // Release the crew only if their pointer still refers to this job
                if (crewRef != null && crewSnapshot?.getString("activeJobId") == workOrderId) {
                    tx.update(crewRef, "activeJobId", null)
                }
                tx.delete(orderRef)
                null
            }.await()
            if (problem == null) Result.success(Unit)
            else Result.failure(IllegalStateException(problem))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createWorkOrderWithNewClient(client: Client, workOrder: WorkOrder): Result<String> {
        return try {
            val db = FirebaseFirestore.getInstance()
            val clientRef = db.collection("clients").document()
            val orderRef = workOrdersCollection.document()
            db.batch()
                .set(clientRef, client.copy(clientId = clientRef.id))
                .set(orderRef, workOrder.copy(workOrderId = orderRef.id, clientId = clientRef.id))
                .commit().await()
            Result.success(orderRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun claimWorkOrder(workOrderId: String, crewUserId: String): Result<ClaimOutcome> {
        return try {
            val outcome = firestore.runTransaction { tx ->
                val userRef = usersCollection.document(crewUserId)
                val orderRef = workOrdersCollection.document(workOrderId)

                // All reads first: Firestore requires reads before writes in a transaction
                val user = tx.get(userRef)
                val order = tx.get(orderRef)
                val currentJobId = user.getString("activeJobId")
                val currentJob = if (currentJobId.isNullOrBlank()) null
                else tx.get(workOrdersCollection.document(currentJobId))

                if (!order.exists() || order.getString("status") != "PENDING") {
                    return@runTransaction ClaimOutcome.JOB_UNAVAILABLE
                }

                // activeJobId is only a pointer: a deleted or finished job must not lock the crew out
                val hasLiveJob = currentJob != null && currentJob.exists() &&
                        currentJob.getString("status") == "IN_PROGRESS" &&
                        currentJob.getString("assignedCrew") == crewUserId
                if (hasLiveJob) return@runTransaction ClaimOutcome.CREW_BUSY

                tx.update(
                    orderRef, mapOf(
                        "status" to "IN_PROGRESS",
                        "assignedCrew" to crewUserId,
                        "assignedCrewName" to user.getString("fullName"),
                        "teamColour" to user.getString("teamColour"),
                        "claimedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(userRef, "activeJobId", workOrderId)
                ClaimOutcome.CLAIMED
            }.await()
            Result.success(outcome)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Completing a job and creating its invoice happen in ONE transaction:
    // a job can never be completed without an invoice, and never gets two.
    // The crew must have pressed Start first, so a job can't be claimed and completed in one go.
    suspend fun completeWorkOrder(workOrderId: String, crewUserId: String): Result<Unit> {
        return try {
            val problem = firestore.runTransaction<String?> { tx ->
                val orderRef = workOrdersCollection.document(workOrderId)
                val invoiceRef = invoicesCollection.document(workOrderId) // same ID as the job
                val counterRef = countersCollection.document("invoices")

                // All reads first: Firestore requires reads before writes in a transaction
                val order = tx.get(orderRef)
                val existingInvoice = tx.get(invoiceRef)
                val counter = tx.get(counterRef)

                // Only the crew holding an in-progress job can complete it
                if (order.getString("status") != "IN_PROGRESS" ||
                    order.getString("assignedCrew") != crewUserId
                ) {
                    return@runTransaction "Job is no longer in progress"
                }
                if (order.millisOf("startedAt") == 0L) {
                    return@runTransaction "Press Start Job before completing the job"
                }

                tx.update(
                    orderRef, mapOf(
                        "status" to "COMPLETED",
                        "completedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(usersCollection.document(crewUserId), "activeJobId", null)

                if (!existingInvoice.exists()) {
                    val nextNumber = (counter.getLong("last") ?: 0L) + 1
                    tx.set(counterRef, mapOf("last" to nextNumber))
                    tx.set(
                        invoiceRef,
                        Invoice(
                            invoiceId = workOrderId,
                            invoiceNumber = "INV-%04d".format(nextNumber),
                            workOrderId = workOrderId,
                            clientId = order.getString("clientId") ?: "",
                            clientName = order.getString("clientName") ?: "",
                            clientPhone = order.getString("clientPhone") ?: "",
                            siteAddress = order.getString("siteAddress") ?: "",
                            serviceDetails = order.getString("serviceDetails") ?: "",
                            amountZAR = order.getDouble("amountZAR") ?: 0.0,
                            paymentStatus = "UNPAID",
                            issuedDate = System.currentTimeMillis()
                        )
                    )
                }
                null
            }.await()

            if (problem == null) Result.success(Unit)
            else Result.failure(IllegalStateException(problem))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }


    // Puts an in-progress job back to PENDING for every crew and frees the crew who held it.
    suspend fun releaseWorkOrder(workOrderId: String, crewUserId: String): Result<Unit> {
        return try {
            val released = firestore.runTransaction { tx ->
                val orderRef = workOrdersCollection.document(workOrderId)
                val order = tx.get(orderRef)

                // Only the crew holding the in-progress job can release it
                if (order.getString("status") != "IN_PROGRESS" ||
                    order.getString("assignedCrew") != crewUserId
                ) {
                    return@runTransaction false
                }

                tx.update(
                    orderRef, mapOf(
                        "status" to "PENDING",
                        "assignedCrew" to null,
                        "assignedCrewName" to null,
                        "teamColour" to null,
                        "claimedAt" to null,
                        "onTheWayAt" to null,
                        "startedAt" to null,
                        "teamMembers" to emptyList<String>()
                    )
                )
                tx.update(usersCollection.document(crewUserId), "activeJobId", null)
                true
            }.await()

            if (released) Result.success(Unit)
            else Result.failure(IllegalStateException("Job is no longer yours"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // The crew tells the client they are travelling to the site. Optional step.
    suspend fun markOnTheWay(workOrderId: String, crewUserId: String): Result<Unit> =
        stampJob(workOrderId, crewUserId, "onTheWayAt")

    // The crew has arrived and the work begins. Required before the job can be completed.
    // The names of the team members on the job are saved with the start time.
    suspend fun startWorkOrder(
        workOrderId: String,
        crewUserId: String,
        teamMembers: List<String>
    ): Result<Unit> {
        if (teamMembers.isEmpty()) {
            return Result.failure(IllegalStateException("Select at least one team member"))
        }
        return stampJob(workOrderId, crewUserId, "startedAt", mapOf("teamMembers" to teamMembers))
    }

    // Writes the server time once (plus any extra fields) for the crew holding the job.
    // Pressing twice changes nothing, so the first recorded time can never be overwritten.
    private suspend fun stampJob(
        workOrderId: String,
        crewUserId: String,
        field: String,
        extra: Map<String, Any> = emptyMap()
    ): Result<Unit> {
        return try {
            val problem = firestore.runTransaction<String?> { tx ->
                val orderRef = workOrdersCollection.document(workOrderId)
                val order = tx.get(orderRef)
                if (order.getString("status") != "IN_PROGRESS" ||
                    order.getString("assignedCrew") != crewUserId
                ) {
                    return@runTransaction "Job is no longer yours"
                }
                if (order.millisOf(field) == 0L) {
                    tx.update(orderRef, mapOf<String, Any>(field to FieldValue.serverTimestamp()) + extra)
                }
                null
            }.await()
            if (problem == null) Result.success(Unit)
            else Result.failure(IllegalStateException(problem))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

private fun DocumentSnapshot.toWorkOrder(): WorkOrder? = try {
    val createdAt = when (val raw = get("createdAt")) {
        is Timestamp -> raw.toDate().time
        is Number -> raw.toLong()
        else -> System.currentTimeMillis()
    }
    WorkOrder(
        workOrderId = getString("workOrderId") ?: id,
        clientId = getString("clientId") ?: "",
        clientName = getString("clientName") ?: "",
        contactPerson = getString("contactPerson") ?: "",
        clientPhone = getString("clientPhone") ?: "",
        siteAddress = getString("siteAddress") ?: "",
        serviceDetails = getString("serviceDetails") ?: "",
        amountZAR = getDouble("amountZAR") ?: 0.0,
        scheduledTime = getString("scheduledTime") ?: "",
        scheduledAt = getLong("scheduledAt") ?: 0L,
        status = getString("status") ?: "PENDING",
        assignedCrew = getString("assignedCrew"),
        assignedCrewName = getString("assignedCrewName"),
        teamColour = getString("teamColour"),
        claimedAt = millisOf("claimedAt"),
        onTheWayAt = millisOf("onTheWayAt"),
        startedAt = millisOf("startedAt"),
        completedAt = millisOf("completedAt"),
        teamMembers = (get("teamMembers") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
        overdueNotified = getBoolean("overdueNotified") ?: false,
        rescheduleCount = (getLong("rescheduleCount") ?: 0L).toInt(),
        createdAt = createdAt
    )
} catch (e: Exception) {
    null // skip malformed documents rather than crashing
}

// Step times are written by the server as Timestamps; 0 means the step hasn't happened yet
private fun DocumentSnapshot.millisOf(field: String): Long = when (val raw = get(field)) {
    is Timestamp -> raw.toDate().time
    is Number -> raw.toLong()
    else -> 0L
}