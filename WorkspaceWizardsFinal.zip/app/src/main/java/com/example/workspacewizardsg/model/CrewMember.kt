package com.example.workspacewizardsg.model

// A member of a crew. Members have no login: the crew's own account (the team leader) manages them.
data class CrewMember(
    val memberId: String = "",
    val crewId: String = "",        // the crew leader's user ID
    val firstName: String = "",
    val lastName: String = "",
    val available: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

// Not a property of the class, so it is never written to Firestore
val CrewMember.fullName: String
    get() = "$firstName $lastName"