package com.example.workspacewizardsg.uii

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.viewmodel.SearchViewModel

private enum class SearchCategory(val label: String) {
    ALL("All"),
    CLIENTS("Clients"),
    WORK_ORDERS("Work Orders"),
    INVOICES("Invoices")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onNavigateBack: () -> Unit,
    onHome: () -> Unit,
    onWorkOrderTapped: (workOrderId: String) -> Unit,
    viewModel: SearchViewModel = viewModel()
) {
    val data by viewModel.data.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    var categoryIndex by rememberSaveable { mutableIntStateOf(0) }
    val category = SearchCategory.entries[categoryIndex]
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()

    val hasQuery = query.isNotBlank()
    val clientResults =
        if (hasQuery && (category == SearchCategory.ALL || category == SearchCategory.CLIENTS))
            viewModel.matchingClients(data, query) else emptyList()
    val workOrderResults =
        if (hasQuery && (category == SearchCategory.ALL || category == SearchCategory.WORK_ORDERS))
            viewModel.matchingWorkOrders(data, query) else emptyList()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            AppTopBar(
                title = "Global Search",
                onBack = onNavigateBack,
                onHome = onHome,
                scrollBehavior = scrollBehavior
            )
        }
    ) { innerPadding ->
        // One list for the whole page, so the search field and filters scroll away with the results
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "search") {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search clients, jobs, invoices...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }
            item(key = "filters") {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SearchCategory.entries.forEachIndexed { index, item ->
                        FilterChip(
                            selected = index == categoryIndex,
                            onClick = { categoryIndex = index },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
            when {
                data.isLoading -> item(key = "loading") {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                !hasQuery -> message("Type a keyword to begin searching across the workspace.")

                // Placeholder: invoice search is added together with the invoices feature
                category == SearchCategory.INVOICES ->
                    message("Invoice search will be available once invoices are added.")

                clientResults.isEmpty() && workOrderResults.isEmpty() ->
                    message("No results for \"${query.trim()}\"")

                else -> {
                    if (clientResults.isNotEmpty()) {
                        item(key = "header_clients") {
                            ResultsHeader("Clients (${clientResults.size})")
                        }
                        items(items = clientResults, key = { "client_${it.clientId}" }) { client ->
                            ClientCard(client)
                        }
                    }
                    if (workOrderResults.isNotEmpty()) {
                        item(key = "header_orders") {
                            ResultsHeader("Work Orders (${workOrderResults.size})")
                        }
                        items(items = workOrderResults, key = { "order_${it.workOrderId}" }) { workOrder ->
                            WorkOrderCard(
                                workOrder = workOrder,
                                onClick = { onWorkOrderTapped(workOrder.workOrderId) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultsHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold
    )
}

// A centred line of text as one item of the results list
private fun LazyListScope.message(text: String) = item(key = "message") {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        textAlign = TextAlign.Center,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}