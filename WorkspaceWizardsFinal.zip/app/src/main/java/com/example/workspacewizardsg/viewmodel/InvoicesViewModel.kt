package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.Invoice
import com.example.workspacewizardsg.repository.InvoiceRepository
import com.example.workspacewizardsg.util.buildWhatsAppUrl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class InvoicesUiState(
    val invoices: List<Invoice> = emptyList(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null
)

class InvoicesViewModel(
    private val repository: InvoiceRepository = InvoiceRepository()
) : ViewModel() {

    private val error = MutableStateFlow<String?>(null)

    val uiState: StateFlow<InvoicesUiState> = combine(
        repository.observeInvoices().catch { emit(emptyList()) },
        error
    ) { invoices, errorMessage ->
        InvoicesUiState(invoices = invoices, isLoading = false, errorMessage = errorMessage)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = InvoicesUiState()
    )

    fun markAsPaid(invoiceId: String) {
        viewModelScope.launch {
            repository.markAsPaid(invoiceId).onFailure {
                error.value = "Could not mark the invoice as paid. Please try again."
            }
        }
    }

    // Null when the client's phone number is not a valid South African number
    fun whatsAppUrl(invoice: Invoice): String? = buildWhatsAppUrl(invoice)

    fun unpaidTotal(invoices: List<Invoice>): Double =
        invoices.filter { it.paymentStatus == "UNPAID" }.sumOf { it.amountZAR }

    fun unpaidCount(invoices: List<Invoice>): Int =
        invoices.count { it.paymentStatus == "UNPAID" }

    fun clearError() {
        error.value = null
    }
}