package com.example.workspacewizardsg.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = Teal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD3EAEC),
    onPrimaryContainer = Color(0xFF00363B),
    secondary = TealDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE2ECED),
    onSecondaryContainer = TextPrimary,
    tertiary = PinkAccent,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFEFEFEF),
    onTertiaryContainer = TextPrimary,
    background = BackgroundLight,
    onBackground = TextPrimary,
    surface = SurfaceWhite,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    outline = Color(0xFF7A8B8D),
    outlineVariant = BorderGrey
)

@Composable
fun WorkspaceWizardsGTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}