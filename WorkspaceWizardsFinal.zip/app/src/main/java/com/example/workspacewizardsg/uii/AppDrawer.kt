package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemColors
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll


// Pages where the drawer can be opened: the bottom bar pages plus Invoices
val drawerRoutes: Set<String> = bottomBarRoutes + invoicesDestination.route + crewsDestination.route

private val drawerItems = bottomBarItems + invoicesDestination + crewsDestination

@Composable
fun AppDrawerContent(
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    onSignOut: () -> Unit
) {
    val contentColor = MaterialTheme.colorScheme.onPrimary
    val itemColors: NavigationDrawerItemColors = NavigationDrawerItemDefaults.colors(
        unselectedContainerColor = Color.Transparent,
        selectedContainerColor = contentColor.copy(alpha = 0.18f),
        unselectedTextColor = contentColor,
        selectedTextColor = contentColor,
        unselectedIconColor = contentColor,
        selectedIconColor = contentColor
    )

    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.primary) {
        // One scrolling column holds the header, every item and Sign out
        Column(
            modifier = Modifier
                .fillMaxSize()
                .dotGrid(contentColor)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 28.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                WizardLogo(size = 44.dp)
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "Workspace Wizards",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                    Text(
                        text = "Admin Portal",
                        style = MaterialTheme.typography.bodySmall,
                        color = contentColor.copy(alpha = 0.8f)
                    )
                }
            }

            drawerItems.forEach { item ->
                NavigationDrawerItem(
                    label = { Text(item.label) },
                    icon = { Icon(item.icon, contentDescription = null) },
                    selected = currentRoute == item.route,
                    onClick = { onNavigate(item.route) },
                    colors = itemColors,
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }

            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                color = contentColor.copy(alpha = 0.3f)
            )

            NavigationDrawerItem(
                label = { Text("Sign out") },
                icon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null) },
                selected = false,
                onClick = onSignOut,
                colors = itemColors,
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
            )
        }
    }
}

