package com.example.workspacewizardsg.util

// Input checks shared by every form. Each function returns an error message, or null when the
// value is acceptable. Pure Kotlin (no Android or Firebase), so it can be unit tested on its own.

const val MAX_AMOUNT_ZAR = 1_000_000.0

private val PERSON_NAME = Regex("^\\p{L}+(?:[ '’\\-]\\p{L}+)*$")
private val COMPANY_NAME = Regex("^[\\p{L}\\p{N} &.,'’()/\\-]+$")
private val EMAIL = Regex("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9\\-]+(?:\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,}$")

// Letters only, with single spaces, hyphens or apostrophes between parts (Mary-Jane, O'Neil)
fun personNameError(raw: String, fieldName: String = "Name"): String? {
    val value = raw.trim()
    return when {
        value.isEmpty() -> "$fieldName is required"
        value.length < 2 -> "$fieldName is too short"
        value.length > 50 -> "$fieldName is too long"
        !PERSON_NAME.matches(value) ->
            "$fieldName can only contain letters, spaces, hyphens and apostrophes"
        else -> null
    }
}

// Digits are allowed (3M, Pick n Pay 24) but the name must contain at least one letter
fun companyNameError(raw: String): String? {
    val value = raw.trim()
    return when {
        value.isEmpty() -> "Company name is required"
        value.length < 2 -> "Company name is too short"
        value.length > 80 -> "Company name is too long"
        !COMPANY_NAME.matches(value) -> "Company name contains characters that aren't allowed"
        value.none { it.isLetter() } -> "Company name must contain at least one letter"
        else -> null
    }
}

// South African local format: exactly 10 digits starting with 0. Spaces and hyphens are tolerated.
fun phoneError(raw: String): String? {
    val value = raw.trim()
    if (value.isEmpty()) return "Phone number is required"
    if (!value.all { it in '0'..'9' || it == ' ' || it == '-' }) {
        return "Phone number can only contain digits"
    }
    val digits = value.filter { it in '0'..'9' }
    return when {
        digits.length != 10 -> "Phone number must be exactly 10 digits"
        digits[0] != '0' -> "Phone number must start with 0"
        digits[1] == '0' || digits.drop(1).all { it == digits[1] } -> "Enter a valid phone number"
        else -> null
    }
}

fun emailError(raw: String, required: Boolean = true): String? {
    val value = raw.trim()
    if (value.isEmpty()) return if (required) "Email is required" else null
    return when {
        value.length > 254 -> "Email is too long"
        ".." in value -> "Email can't contain two dots in a row"
        !EMAIL.matches(value) -> "Enter a valid email address, for example name@company.co.za"
        value.substringBefore('@').let { it.startsWith('.') || it.endsWith('.') } ->
            "Email can't start or end with a dot before the @"
        else -> null
    }
}

fun addressError(raw: String): String? {
    val value = raw.trim()
    return when {
        value.isEmpty() -> "Site address is required"
        value.length < 5 -> "Site address is too short"
        value.length > 150 -> "Site address is too long"
        value.none { it.isLetter() } -> "Site address must contain letters, not only numbers"
        else -> null
    }
}

fun serviceDetailsError(raw: String): String? {
    val value = raw.trim()
    return when {
        value.isEmpty() -> "Service details are required"
        value.length < 10 -> "Describe the job in at least 10 characters"
        value.length > 500 -> "Service details are too long (500 characters at most)"
        value.none { it.isLetter() } -> "Service details must contain words, not only numbers"
        else -> null
    }
}

fun amountError(raw: String): String? {
    val value = raw.trim()
    if (value.isEmpty()) return "Amount is required"
    val amount = value.toDoubleOrNull() ?: return "Enter a valid amount"
    return when {
        amount <= 0 -> "Amount must be greater than 0"
        amount > MAX_AMOUNT_ZAR -> "Amount can't be more than R 1 000 000"
        else -> null
    }
}

// original = the job's existing date when editing, so an unchanged past date can still be saved
fun scheduledError(
    scheduledAt: Long?,
    now: Long = System.currentTimeMillis(),
    original: Long? = null
): String? = when {
    scheduledAt == null -> "Pick a date and time"
    scheduledAt == original -> null
    scheduledAt <= now -> "Pick a date and time in the future"
    else -> null
}