package com.example.workspacewizardsg.util

import com.example.workspacewizardsg.model.Invoice
import com.example.workspacewizardsg.model.WorkOrder

data class InvoiceLine(
    val number: String,
    val client: String,
    val issued: Long,
    val amount: Double,
    val paid: Boolean
)

// Everything the financial summary shows, worked out once so the screen and the PDF agree.
data class FinancialReport(
    val generatedAt: Long = 0L,
    val completedJobs: Int = 0,
    val revenue: Double = 0.0,          // all completed jobs
    val collected: Double = 0.0,        // paid invoices
    val collectedCount: Int = 0,
    val outstanding: Double = 0.0,      // unpaid invoices
    val outstandingCount: Int = 0,
    val months: List<MonthRevenue> = emptyList(),
    val invoices: List<InvoiceLine> = emptyList()   // newest first
)

fun buildFinancialReport(
    orders: List<WorkOrder>,
    invoices: List<Invoice>,
    now: Long = System.currentTimeMillis()
): FinancialReport {
    val paid = invoices.filter { it.paymentStatus == "PAID" }
    val unpaid = invoices.filter { it.paymentStatus == "UNPAID" }
    return FinancialReport(
        generatedAt = now,
        completedJobs = orders.count { it.status == "COMPLETED" },
        revenue = completedRevenue(orders),
        collected = paid.sumOf { it.amountZAR },
        collectedCount = paid.size,
        outstanding = unpaid.sumOf { it.amountZAR },
        outstandingCount = unpaid.size,
        months = revenueByMonth(orders, now = now),
        invoices = invoices.sortedByDescending { it.issuedDate }.map {
            InvoiceLine(
                number = it.invoiceNumber,
                client = it.clientName,
                issued = it.issuedDate,
                amount = it.amountZAR,
                paid = it.paymentStatus == "PAID"
            )
        }
    )
}

