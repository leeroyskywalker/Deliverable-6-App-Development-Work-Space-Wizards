package com.example.workspacewizardsg.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// One format everywhere a date is shown, in the device's time zone, e.g. "Mon 9 Nov 2026, 13:04"
fun formatDateTime(epochMillis: Long): String =
    SimpleDateFormat("EEE d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(epochMillis))

// How long a job took, e.g. "45 min", "2 h", "1 h 20 min"
fun formatDuration(startMillis: Long, endMillis: Long): String {
    val minutes = ((endMillis - startMillis) / 60_000).coerceAtLeast(0)
    val hours = minutes / 60
    val rest = minutes % 60
    return when {
        minutes < 1 -> "Less than 1 min"
        hours == 0L -> "$minutes min"
        rest == 0L -> "$hours h"
        else -> "$hours h $rest min"
    }
}