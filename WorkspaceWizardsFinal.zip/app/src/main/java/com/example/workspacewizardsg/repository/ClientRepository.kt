package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.Client
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ClientRepository {

    private val firestore = FirebaseFirestore.getInstance()
    private val clientsCollection = firestore.collection("clients")
    private val workOrdersCollection = firestore.collection("workOrders")

    // Real-time stream of all clients for the picker dropdown and the Contact Directory
    fun observeClients(): Flow<List<Client>> = callbackFlow {
        val listener = clientsCollection
            .orderBy("companyName")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val clients = snapshot?.documents?.mapNotNull {
                    it.toObject(Client::class.java)
                } ?: emptyList()
                trySend(clients)
            }
        awaitClose { listener.remove() }
    }

    // One write: the document ID is generated first and stored inside the document
    suspend fun addClient(client: Client): Result<String> {
        return try {
            val ref = clientsCollection.document()
            ref.set(client.copy(clientId = ref.id)).await()
            Result.success(ref.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Only the editable fields change. Existing jobs and invoices keep their own copy of the details.
    suspend fun updateClient(client: Client): Result<Unit> {
        return try {
            clientsCollection.document(client.clientId).update(
                mapOf(
                    "companyName" to client.companyName,
                    "contactPerson" to client.contactPerson,
                    "phone" to client.phone,
                    "siteAddress" to client.siteAddress
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // A client that still has work orders cannot be deleted, so jobs never point to a missing client.
    suspend fun deleteClient(clientId: String): Result<Unit> {
        return try {
            val hasWorkOrders = !workOrdersCollection
                .whereEqualTo("clientId", clientId)
                .limit(1)
                .get()
                .await()
                .isEmpty
            if (hasWorkOrders) {
                Result.failure(IllegalStateException("This client has work orders and can't be deleted"))
            } else {
                clientsCollection.document(clientId).delete().await()
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}