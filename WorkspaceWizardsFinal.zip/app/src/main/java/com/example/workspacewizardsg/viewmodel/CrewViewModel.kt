package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.repository.AuthRepository
import com.example.workspacewizardsg.model.ADMIN_AUDIENCE
import com.example.workspacewizardsg.repository.ClaimOutcome
import com.example.workspacewizardsg.repository.NotificationRepository
import com.example.workspacewizardsg.repository.UserRepository
import com.example.workspacewizardsg.repository.WorkOrderRepository
import com.example.workspacewizardsg.util.greetingName
import com.example.workspacewizardsg.util.jobStartedMessage
import com.example.workspacewizardsg.util.onTheWayMessage
import com.example.workspacewizardsg.util.whatsAppUrl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CrewUiState(
    val crewName: String = "",
    val teamColour: String = "",
    val activeJob: WorkOrder? = null,
    val pendingJobs: List<WorkOrder> = emptyList(),
    val completedJobs: List<WorkOrder> = emptyList(),
    val isLoading: Boolean = true,
    val isBusy: Boolean = false,
    val message: String? = null,
    // A ready-to-open WhatsApp chat with the client, set after "On my way" and "Start Job"
    val clientChatUrl: String? = null
)

class CrewViewModel(
    private val workOrderRepository: WorkOrderRepository = WorkOrderRepository(),
    userRepository: UserRepository = UserRepository(),
    authRepository: AuthRepository = AuthRepository(),
    private val notificationRepository: NotificationRepository = NotificationRepository()
) : ViewModel() {

    val crewUserId: String? = authRepository.currentUser()?.uid

    private val _isBusy = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)
    private val _clientChatUrl = MutableStateFlow<String?>(null)

    // .catch: after sign-out Firestore rejects open listeners, which must not crash the app
    val uiState: StateFlow<CrewUiState> = combine(
        (if (crewUserId == null) flowOf(null) else userRepository.observeUser(crewUserId))
            .catch { emit(null) },
        workOrderRepository.observeAllWorkOrders().catch { emit(emptyList()) },
        _isBusy,
        _message,
        _clientChatUrl
    ) { user, orders, busy, message, chatUrl ->
        CrewUiState(
            crewName = user?.fullName.orEmpty(),
            teamColour = user?.teamColour.orEmpty(),
            activeJob = orders.firstOrNull {
                it.workOrderId == user?.activeJobId &&
                        it.status == "IN_PROGRESS" &&
                        it.assignedCrew == crewUserId
            },
            pendingJobs = orders.filter { it.status == "PENDING" },
            completedJobs = orders
                .filter { it.status == "COMPLETED" && it.assignedCrew == crewUserId }
                .sortedByDescending { if (it.completedAt > 0) it.completedAt else it.createdAt },
            isLoading = false,
            isBusy = busy,
            message = message,
            clientChatUrl = chatUrl
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = CrewUiState()
    )

    fun takeJob(workOrderId: String) {
        val userId = crewUserId ?: return
        if (_isBusy.value) return
        val job = uiState.value.pendingJobs.firstOrNull { it.workOrderId == workOrderId }
        viewModelScope.launch {
            _isBusy.value = true
            workOrderRepository.claimWorkOrder(workOrderId, userId).fold(
                onSuccess = { outcome ->
                    _message.value = when (outcome) {
                        ClaimOutcome.CLAIMED -> {
                            tellAdmin("claimed the job for", job?.clientName, workOrderId)
                            null
                        }
                        ClaimOutcome.JOB_UNAVAILABLE -> "That job was just taken by another crew"
                        ClaimOutcome.CREW_BUSY -> "Finish your current job first"
                    }
                },
                onFailure = { _message.value = "Could not take the job. Check your connection." }
            )
            _isBusy.value = false
        }
    }

    fun onMyWay() = runOnActiveJob(
        failureMessage = "Could not send your update. Check your connection.",
        adminUpdate = "is on the way to",
        clientMessage = ::onTheWayMessage
    ) { jobId, userId ->
        workOrderRepository.markOnTheWay(jobId, userId)
    }

    fun startJob(teamMembers: List<String>) = runOnActiveJob(
        failureMessage = "Could not start the job. Check your connection.",
        adminUpdate = "started the job for",
        clientMessage = ::jobStartedMessage
    ) { jobId, userId ->
        workOrderRepository.startWorkOrder(jobId, userId, teamMembers)
    }

    fun completeJob() = runOnActiveJob(
        failureMessage = "Could not complete the job. Check your connection.",
        adminUpdate = "completed the job for"
    ) { jobId, userId ->
        workOrderRepository.completeWorkOrder(jobId, userId)
    }

    fun releaseJob() = runOnActiveJob(
        failureMessage = "Could not release the job. Check your connection.",
        successMessage = "Job released. It is available to all crews again.",
        adminUpdate = "released the job for"
    ) { jobId, userId ->
        workOrderRepository.releaseWorkOrder(jobId, userId)
    }

    // Runs one step on the crew's active job. A refusal from the repository (for example
    // "Press Start Job before completing the job") is shown as it is; any other failure is
    // treated as a connection problem. adminUpdate, when given, is sent to the admin's bell on success.
    // clientMessage, when given, builds the WhatsApp text that tells the client about the step.
    private fun runOnActiveJob(
        failureMessage: String,
        successMessage: String? = null,
        adminUpdate: String? = null,
        clientMessage: ((greeting: String, crewName: String, siteAddress: String) -> String)? = null,
        action: suspend (workOrderId: String, userId: String) -> Result<Unit>
    ) {
        val userId = crewUserId ?: return
        val job = uiState.value.activeJob ?: return
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            action(job.workOrderId, userId).fold(
                onSuccess = {
                    _message.value = successMessage
                    adminUpdate?.let { tellAdmin(it, job.clientName, job.workOrderId) }
                    clientMessage?.let { prepareClientChat(job, it) }
                },
                onFailure = { e ->
                    _message.value = if (e is IllegalStateException) e.message else failureMessage
                }
            )
            _isBusy.value = false
        }
    }

    // The step is already saved; this only prepares the WhatsApp message for the crew to send
    private fun prepareClientChat(
        job: WorkOrder,
        message: (greeting: String, crewName: String, siteAddress: String) -> String
    ) {
        val text = message(
            greetingName(job.contactPerson, job.clientName),
            uiState.value.crewName.ifBlank { "our crew" },
            job.siteAddress
        )
        val url = whatsAppUrl(job.clientPhone, text)
        if (url != null) _clientChatUrl.value = url
        else _message.value = "Saved, but the client's phone number can't be used for WhatsApp"
    }

    fun clearClientChat() { _clientChatUrl.value = null }

    // Best effort: a failed notification must never undo or block the step that just succeeded
    private suspend fun tellAdmin(action: String, clientName: String?, workOrderId: String) {
        val who = uiState.value.crewName.ifBlank { "A crew" }
        notificationRepository.send(ADMIN_AUDIENCE, "$who $action ${clientName ?: "a client"}", workOrderId)
    }

    fun clearMessage() { _message.value = null }
}
