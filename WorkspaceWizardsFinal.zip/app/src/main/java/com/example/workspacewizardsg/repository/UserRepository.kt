package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.User
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class UserRepository {

    private val usersCollection = FirebaseFirestore.getInstance().collection("users")

    // Real-time stream of one user's profile (name, team colour, active job)
    fun observeUser(userId: String): Flow<User?> = callbackFlow {
        val listener = usersCollection.document(userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                // A malformed document becomes null instead of crashing the app
                trySend(runCatching { snapshot?.toObject(User::class.java) }.getOrNull())
            }
        awaitClose { listener.remove() }
    }
}

