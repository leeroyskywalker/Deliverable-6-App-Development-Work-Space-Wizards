package com.example.workspacewizardsg.uii

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.util.addressError
import com.example.workspacewizardsg.util.adminJobMessage
import com.example.workspacewizardsg.util.amountError
import com.example.workspacewizardsg.util.dueStatus
import com.example.workspacewizardsg.util.formatDateTime
import com.example.workspacewizardsg.util.formatDuration
import com.example.workspacewizardsg.util.greetingName
import com.example.workspacewizardsg.util.isOverdue
import com.example.workspacewizardsg.util.scheduledError
import com.example.workspacewizardsg.util.serviceDetailsError
import com.example.workspacewizardsg.util.whatsAppUrl
import com.example.workspacewizardsg.viewmodel.WorkOrderDetailViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkOrderDetailScreen(
    onNavigateBack: () -> Unit,
    viewModel: WorkOrderDetailViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showReschedule by remember { mutableStateOf(false) }
    val order = uiState.workOrder
    val canModify = order != null && order.status != "COMPLETED"

    LaunchedEffect(uiState.deleted) {
        if (uiState.deleted) onNavigateBack()
    }
    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            BrandTopBar(
                title = { Text("Work Order") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (canModify) {
                        IconButton(
                            onClick = { showDeleteDialog = true },
                            enabled = !uiState.isDeleting
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete work order")
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                uiState.isLoading ->
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                order == null ->
                    Text(
                        text = "This work order no longer exists.",
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp)
                    )
                uiState.isEditing ->
                    EditForm(
                        order = order,
                        isSaving = uiState.isSaving,
                        formError = uiState.formError,
                        onSave = viewModel::save,
                        onCancel = viewModel::cancelEditing
                    )
                else ->
                    DetailView(
                        order = order,
                        canModify = canModify,
                        onEdit = viewModel::startEditing,
                        onReschedule = { showReschedule = true }
                    )
            }
        }
    }

    if (showReschedule && order != null) {
        RescheduleDialog(
            order = order,
            onConfirm = { newDate ->
                showReschedule = false
                viewModel.reschedule(newDate)
            },
            onDismiss = { showReschedule = false }
        )
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete this work order?") },
            text = {
                Text(
                    if (order?.status == "IN_PROGRESS")
                        "This job is in progress. Deleting it will release " +
                                "${order.assignedCrewName ?: "the assigned crew"} so they can take another job."
                    else
                        "This can't be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    viewModel.delete()
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun DetailView(
    order: WorkOrder,
    canModify: Boolean,
    onEdit: () -> Unit,
    onReschedule: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = order.clientName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    StatusBadge(order.status)
                }
                order.contactPerson.takeIf { it.isNotBlank() }?.let { DetailRow("Contact person", it) }
                DetailRow("Client phone", order.clientPhone)
                DetailRow("Site address", order.siteAddress)
                DetailRow("Service details", order.serviceDetails)
                DetailRow("Amount", "R %.2f".format(Locale.US, order.amountZAR))
                DetailRow("Scheduled", order.scheduledTime)
                dueStatus(order)?.let { DueBadge(it) }
                if (order.rescheduleCount > 0) {
                    DetailRow("Rescheduled", if (order.rescheduleCount == 1) "1 time" else "${order.rescheduleCount} times")
                }
                DetailRow("Added", formatDateTime(order.createdAt))
                order.claimedAt.takeIf { it > 0 }?.let { DetailRow("Claimed", formatDateTime(it)) }
                order.onTheWayAt.takeIf { it > 0 }?.let { DetailRow("On the way", formatDateTime(it)) }
                order.startedAt.takeIf { it > 0 }?.let { DetailRow("Started", formatDateTime(it)) }
                order.completedAt.takeIf { it > 0 }?.let { DetailRow("Completed", formatDateTime(it)) }
                if (order.startedAt > 0 && order.completedAt > 0) {
                    DetailRow("Duration", formatDuration(order.startedAt, order.completedAt))
                }
                order.assignedCrewName?.let { crew -> CrewRow(crew, order.teamColour) }
                if (order.teamMembers.isNotEmpty()) {
                    DetailRow("Team members", order.teamMembers.joinToString(", "))
                }
            }
        }

        val context = LocalContext.current
        val chatUrl = whatsAppUrl(
            order.clientPhone,
            adminJobMessage(
                greetingName(order.contactPerson, order.clientName),
                order.siteAddress,
                order.scheduledTime
            )
        )
        OutlinedButton(
            onClick = { chatUrl?.let { openWhatsAppChat(context, it) } },
            enabled = chatUrl != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (chatUrl != null) "Message client on WhatsApp" else "Client phone can't be used for WhatsApp") }

        if (canModify) {
            if (isOverdue(order)) {
                Button(
                    onClick = onReschedule,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Reschedule overdue job") }
            }
            Button(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text("Edit") }
        } else {
            Text(
                text = "Completed jobs can't be edited or deleted.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(text = value.ifBlank { "-" }, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun CrewRow(crewName: String, teamColour: String?) {
    val colour = teamColour?.let {
        runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull()
    }
    Column {
        Text(
            text = "Assigned crew",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (colour != null) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(colour, CircleShape)
                )
                Spacer(Modifier.width(8.dp))
            }
            Text(text = crewName, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

// Asks only for the new date; the rest of the job stays as it is
@Composable
private fun RescheduleDialog(order: WorkOrder, onConfirm: (Long) -> Unit, onDismiss: () -> Unit) {
    var newDate by remember { mutableStateOf<Long?>(null) }
    val problem = scheduledError(newDate)
    val crewNote = order.assignedCrewName?.let { " $it will be told." }.orEmpty()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reschedule job") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("${order.clientName} was due ${formatDateTime(order.scheduledAt)}.$crewNote")
                DateTimeField(
                    label = "New date & time",
                    valueMillis = newDate,
                    onValueChange = { newDate = it },
                    error = problem,
                    showErrors = false
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { newDate?.let(onConfirm) },
                enabled = newDate != null && problem == null
            ) { Text("Reschedule") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun EditForm(
    order: WorkOrder,
    isSaving: Boolean,
    formError: String?,
    onSave: (siteAddress: String, serviceDetails: String, amount: String, scheduledAt: Long?) -> Unit,
    onCancel: () -> Unit
) {
    var siteAddress by remember { mutableStateOf(order.siteAddress) }
    var serviceDetails by remember { mutableStateOf(order.serviceDetails) }
    // Locale.US so the decimal separator is always "." and the amount parses back correctly
    var amountInput by remember { mutableStateOf(String.format(Locale.US, "%.2f", order.amountZAR)) }
    // Older jobs only have free text, so they start empty and the admin picks a real date
    val originalScheduledAt = order.scheduledAt.takeIf { it > 0 }
    var scheduledAt by remember { mutableStateOf(originalScheduledAt) }
    var showErrors by remember { mutableStateOf(false) }

    val addressProblem = addressError(siteAddress)
    val detailsProblem = serviceDetailsError(serviceDetails)
    val amountProblem = amountError(amountInput)
    val scheduleProblem = scheduledError(scheduledAt, original = originalScheduledAt)
    val isValid = listOf(addressProblem, detailsProblem, amountProblem, scheduleProblem)
        .all { it == null }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Client: ${order.clientName}",
            style = MaterialTheme.typography.titleMedium
        )
        ValidatedField(
            value = siteAddress,
            onValueChange = { siteAddress = it },
            label = "Site address",
            error = addressProblem,
            showErrors = showErrors,
            singleLine = false
        )
        ValidatedField(
            value = serviceDetails,
            onValueChange = { serviceDetails = it },
            label = "Service details",
            error = detailsProblem,
            showErrors = showErrors,
            singleLine = false,
            minLines = 3
        )
        ValidatedField(
            value = amountInput,
            onValueChange = {
                if (it.isEmpty() || it.matches(Regex("^\\d*\\.?\\d{0,2}$"))) amountInput = it
            },
            label = "Amount (ZAR)",
            error = amountProblem,
            showErrors = showErrors,
            keyboardType = KeyboardType.Decimal,
            prefix = { Text("R ") }
        )
        DateTimeField(
            label = "Scheduled date & time",
            valueMillis = scheduledAt,
            onValueChange = { scheduledAt = it },
            error = scheduleProblem,
            showErrors = showErrors
        )

        formError?.let {
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Button(
            onClick = {
                showErrors = true
                if (isValid) onSave(siteAddress, serviceDetails, amountInput, scheduledAt)
            },
            enabled = !isSaving,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isSaving) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            } else {
                Text("Save changes")
            }
        }
        OutlinedButton(
            onClick = onCancel,
            enabled = !isSaving,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Cancel") }
    }
}
