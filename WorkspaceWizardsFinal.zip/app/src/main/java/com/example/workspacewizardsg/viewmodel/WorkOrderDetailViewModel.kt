package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.repository.WorkOrderRepository
import com.example.workspacewizardsg.util.addressError
import com.example.workspacewizardsg.util.amountError
import com.example.workspacewizardsg.util.formatDateTime
import com.example.workspacewizardsg.util.rescheduledAlert
import com.example.workspacewizardsg.util.scheduledError
import com.example.workspacewizardsg.util.serviceDetailsError
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class WorkOrderDetailUiState(
    val workOrder: WorkOrder? = null,
    val isLoading: Boolean = true,
    val isEditing: Boolean = false,
    val isSaving: Boolean = false,
    val isDeleting: Boolean = false,
    val formError: String? = null,   // shown inside the edit form
    val message: String? = null,     // shown as a snackbar
    val deleted: Boolean = false
)

class WorkOrderDetailViewModel @JvmOverloads constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: WorkOrderRepository = WorkOrderRepository()
) : ViewModel() {

    // Filled in by Navigation from the route "work_order_detail/{workOrderId}"
    private val workOrderId: String = checkNotNull(savedStateHandle["workOrderId"])

    private val _uiState = MutableStateFlow(WorkOrderDetailUiState())
    val uiState: StateFlow<WorkOrderDetailUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeWorkOrder(workOrderId)
                // after sign-out Firestore rejects open listeners; don't crash
                .catch { _uiState.update { it.copy(workOrder = null, isLoading = false) } }
                .collect { order ->
                    _uiState.update { it.copy(workOrder = order, isLoading = false) }
                }
        }
    }

    fun startEditing() {
        if (_uiState.value.workOrder?.status == "COMPLETED") return
        _uiState.update { it.copy(isEditing = true, formError = null) }
    }

    fun cancelEditing() {
        _uiState.update { it.copy(isEditing = false, formError = null) }
    }

    // The form checks these as the user types; they are repeated here so nothing invalid is saved
    fun save(siteAddress: String, serviceDetails: String, amountInput: String, scheduledAt: Long?) {
        val originalScheduledAt = _uiState.value.workOrder?.scheduledAt?.takeIf { it > 0 }
        val error = addressError(siteAddress)
            ?: serviceDetailsError(serviceDetails)
            ?: amountError(amountInput)
            ?: scheduledError(scheduledAt, original = originalScheduledAt)
        val amount = amountInput.trim().toDoubleOrNull()
        if (error != null || amount == null || scheduledAt == null) {
            _uiState.update { it.copy(formError = error) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null) }
            repository.updateWorkOrderDetails(
                workOrderId, siteAddress.trim(), serviceDetails.trim(), amount,
                formatDateTime(scheduledAt), scheduledAt
            ).fold(
                onSuccess = { _uiState.update { it.copy(isSaving = false, isEditing = false) } },
                onFailure = { e ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            formError = if (e is IllegalStateException) e.message
                            else "Could not save. Check your connection."
                        )
                    }
                }
            )
        }
    }

    // Gives an unfinished job a new date. The crew holding the job is told by the repository.
    fun reschedule(newScheduledAt: Long?) {
        val order = _uiState.value.workOrder ?: return
        val error = scheduledError(newScheduledAt)   // no "original": the new date must be in the future
        if (error != null || newScheduledAt == null) {
            _uiState.update { it.copy(message = error) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            repository.rescheduleWorkOrder(
                workOrderId, newScheduledAt, formatDateTime(newScheduledAt),
                rescheduledAlert(order, newScheduledAt)
            ).fold(
                onSuccess = { _uiState.update { it.copy(isSaving = false, message = "Job rescheduled") } },
                onFailure = { e ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            message = if (e is IllegalStateException) e.message
                            else "Could not reschedule. Check your connection."
                        )
                    }
                }
            )
        }
    }

    fun delete() {
        viewModelScope.launch {
            _uiState.update { it.copy(isDeleting = true) }
            repository.deleteWorkOrder(workOrderId).fold(
                onSuccess = { _uiState.update { it.copy(isDeleting = false, deleted = true) } },
                onFailure = { e ->
                    _uiState.update {
                        it.copy(
                            isDeleting = false,
                            message = if (e is IllegalStateException) e.message
                            else "Could not delete. Check your connection."
                        )
                    }
                }
            )
        }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }
}

