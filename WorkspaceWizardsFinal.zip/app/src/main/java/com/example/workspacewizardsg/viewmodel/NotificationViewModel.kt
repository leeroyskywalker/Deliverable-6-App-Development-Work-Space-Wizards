package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.AppNotification
import com.example.workspacewizardsg.repository.NotificationRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// Serves the bell for whoever is signed in: call start() with ADMIN_AUDIENCE or the crew's user ID.
@OptIn(ExperimentalCoroutinesApi::class)
class NotificationViewModel(
    private val repository: NotificationRepository = NotificationRepository()
) : ViewModel() {

    private val audience = MutableStateFlow<String?>(null)

    // .catch: after sign-out Firestore rejects open listeners, which must not crash the app
    val notifications: StateFlow<List<AppNotification>> = audience
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.observe(id).catch { emit(emptyList()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun start(audienceId: String) {
        audience.value = audienceId
    }

    fun markAllRead() {
        val unread = notifications.value.filter { !it.read }.map { it.notificationId }
        if (unread.isEmpty()) return
        viewModelScope.launch { repository.markRead(unread) }
    }
}

