@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.workspacewizardsg.uii

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.workspacewizardsg.model.AppNotification
import com.example.workspacewizardsg.util.formatDateTime

// The bell for both the admin and the crew. The badge counts unread updates plus jobs that are
// due soon. Updates are marked read when the sheet is closed, so new ones stay highlighted while it is open.
@Composable
fun NotificationBell(
    notifications: List<AppNotification>,
    dueMessages: List<String>,
    onClosed: () -> Unit
) {
    var showSheet by remember { mutableStateOf(false) }
    val badgeCount = notifications.count { !it.read } + dueMessages.size

    IconButton(onClick = { showSheet = true }) {
        BadgedBox(badge = {
            if (badgeCount > 0) Badge { Text(if (badgeCount > 9) "9+" else badgeCount.toString()) }
        }) {
            Icon(Icons.Default.Notifications, contentDescription = "Notifications")
        }
    }

    if (showSheet) {
        ModalBottomSheet(onDismissRequest = {
            showSheet = false
            onClosed()
        }) {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        text = "Notifications",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (dueMessages.isEmpty() && notifications.isEmpty()) {
                    item {
                        Text(
                            text = "You're all caught up",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (dueMessages.isNotEmpty()) {
                    item { SectionLabel("Due soon") }
                    items(dueMessages) { DueRow(it) }
                }
                if (notifications.isNotEmpty()) {
                    item { SectionLabel("Updates") }
                    items(notifications, key = { it.notificationId }) { NotificationRow(it) }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun DueRow(message: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                Icons.Default.Warning,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.onErrorContainer
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}

@Composable
private fun NotificationRow(item: AppNotification) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (item.read) MaterialTheme.colorScheme.surfaceVariant
            else MaterialTheme.colorScheme.secondaryContainer
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = item.message,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (item.read) FontWeight.Normal else FontWeight.SemiBold
            )
            if (item.createdAt > 0L) {
                Text(
                    text = formatDateTime(item.createdAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

