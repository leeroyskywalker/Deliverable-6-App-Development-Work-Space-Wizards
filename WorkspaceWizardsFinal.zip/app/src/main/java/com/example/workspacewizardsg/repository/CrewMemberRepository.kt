package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.CrewMember
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class CrewMemberRepository {

    private val membersCollection = FirebaseFirestore.getInstance().collection("crewMembers")

    // Real-time stream of one crew's members
    fun observeMembers(crewId: String): Flow<List<CrewMember>> = callbackFlow {
        val listener = membersCollection
            .whereEqualTo("crewId", crewId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(
                    snapshot?.documents?.mapNotNull { it.toObject(CrewMember::class.java) }
                        ?: emptyList()
                )
            }
        awaitClose { listener.remove() }
    }

    // Real-time stream of every crew's members, for the admin's availability count
    fun observeAllMembers(): Flow<List<CrewMember>> = callbackFlow {
        val listener = membersCollection.addSnapshotListener { snapshot, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            trySend(
                snapshot?.documents?.mapNotNull { it.toObject(CrewMember::class.java) }
                    ?: emptyList()
            )
        }
        awaitClose { listener.remove() }
    }

    // One write: the document ID is generated first and stored inside the document
    suspend fun addMember(member: CrewMember): Result<Unit> {
        return try {
            val ref = membersCollection.document()
            ref.set(member.copy(memberId = ref.id)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateMember(memberId: String, firstName: String, lastName: String): Result<Unit> {
        return try {
            membersCollection.document(memberId)
                .update(mapOf("firstName" to firstName, "lastName" to lastName)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun setAvailable(memberId: String, available: Boolean): Result<Unit> {
        return try {
            membersCollection.document(memberId).update("available", available).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteMember(memberId: String): Result<Unit> {
        return try {
            membersCollection.document(memberId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}