package com.example.workspacewizardsg.repository

import com.example.workspacewizardsg.model.CrewAccount
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

// Stored in users.role. The app treats every role except "Admin" as a crew.
const val CREW_ROLE = "Crew"
private const val ADMIN_ROLE = "Admin"
private const val CREATOR_APP = "crew-creator"

class CrewAccountRepository {

    private val usersCollection = FirebaseFirestore.getInstance().collection("users")

    // Real-time stream of every crew login
    fun observeCrews(): Flow<List<CrewAccount>> = callbackFlow {
        val listener = usersCollection
            .whereNotEqualTo("role", ADMIN_ROLE)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(
                    snapshot?.documents.orEmpty()
                        .map {
                            CrewAccount(
                                userId = it.id,
                                fullName = it.getString("fullName").orEmpty(),
                                email = it.getString("email").orEmpty(),
                                teamColour = it.getString("teamColour").orEmpty()
                            )
                        }
                        .sortedBy { it.fullName.lowercase() }
                )
            }
        awaitClose { listener.remove() }
    }

    // Creating a login signs that user in. A second FirebaseApp does it on its own session, so the
    // admin stays signed in on the main one. The profile is written as the admin (the rules allow it).
    suspend fun createCrew(fullName: String, email: String, password: String, teamColour: String): Result<Unit> {
        val auth = creatorAuth()
        return try {
            val newUser = auth.createUserWithEmailAndPassword(email, password).await().user
                ?: return Result.failure(IllegalStateException("The login was not created"))
            try {
                usersCollection.document(newUser.uid).set(
                    mapOf(
                        "userId" to newUser.uid,
                        "fullName" to fullName,
                        "email" to email,
                        "role" to CREW_ROLE,
                        "teamColour" to teamColour,
                        "activeJobId" to null,
                        "mfaEnabled" to true,
                        "mfaSecret" to ""
                    )
                ).await()
                Result.success(Unit)
            } catch (e: Exception) {
                // A login without a profile can't be used and would block the email, so remove it
                runCatching { newUser.delete().await() }
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            auth.signOut()
        }
    }

    private fun creatorAuth(): FirebaseAuth {
        val main = FirebaseApp.getInstance()
        val app = runCatching { FirebaseApp.getInstance(CREATOR_APP) }
            .getOrElse { FirebaseApp.initializeApp(main.applicationContext, main.options, CREATOR_APP) }
        return FirebaseAuth.getInstance(app)
    }
}
