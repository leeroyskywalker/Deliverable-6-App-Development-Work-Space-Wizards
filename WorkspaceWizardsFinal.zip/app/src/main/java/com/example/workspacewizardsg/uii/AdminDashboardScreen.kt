package com.example.workspacewizardsg.uii

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.workspacewizardsg.model.ADMIN_AUDIENCE
import com.example.workspacewizardsg.model.WorkOrder
import com.example.workspacewizardsg.util.DueStatus
import com.example.workspacewizardsg.util.dueSoonMessages
import com.example.workspacewizardsg.util.dueStatus
import com.example.workspacewizardsg.util.formatDateTime
import com.example.workspacewizardsg.util.formatDuration
import com.example.workspacewizardsg.util.isOverdue
import com.example.workspacewizardsg.viewmodel.NotificationViewModel
import com.example.workspacewizardsg.viewmodel.OverdueViewModel
import com.example.workspacewizardsg.viewmodel.WorkOrderViewModel

private val OVERDUE_RED = Color(0xFFDC2626)

private const val NEW_BADGE_THRESHOLD_MS = 30 * 60 * 1000L // 30 minutes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    onOpenMenu: () -> Unit,
    onCreateWorkOrder: () -> Unit,
    onOrderStatus: () -> Unit,
    onWorkOrderTapped: (workOrderId: String) -> Unit,
    viewModel: WorkOrderViewModel = viewModel(),
    notificationViewModel: NotificationViewModel = viewModel(),
    overdueViewModel: OverdueViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val notifications by notificationViewModel.notifications.collectAsState()
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior()

    LaunchedEffect(Unit) { notificationViewModel.start(ADMIN_AUDIENCE) }
    // Each time the jobs change, report any that have just gone overdue
    LaunchedEffect(uiState.allWorkOrders) { overdueViewModel.escalate(uiState.allWorkOrders) }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            BrandTopBar(
                title = { Text("Home") },
                navigationIcon = {
                    IconButton(onClick = onOpenMenu) {
                        Icon(Icons.Default.Menu, contentDescription = "Open menu")
                    }
                },
                actions = {
                    NotificationBell(
                        notifications = notifications,
                        dueMessages = dueSoonMessages(uiState.allWorkOrders),
                        onClosed = notificationViewModel::markAllRead
                    )
                },
                scrollBehavior = scrollBehavior
            )
        }
    ) { innerPadding ->
        val allOrders = uiState.allWorkOrders
        // One list for the whole page, so the header scrolls away with the jobs
        // instead of taking up room on a small or sideways screen.
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "header") {
                DashboardHeader(
                    greeting = viewModel.greeting(),
                    activeJobs = viewModel.activeJobCount(allOrders),
                    pending = allOrders.count { it.status == "PENDING" },
                    inProgress = allOrders.count { it.status == "IN_PROGRESS" },
                    dueSoon = allOrders.count { dueStatus(it) != null && !isOverdue(it) },
                    overdue = allOrders.count { isOverdue(it) },
                    onCreateWorkOrder = onCreateWorkOrder,
                    onOrderStatus = onOrderStatus
                )
            }
            item(key = "title") {
                Text(
                    text = "Active Work Orders",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)
                )
            }
            workOrderItems(
                workOrders = viewModel.activeWorkOrders(allOrders),
                isLoading = uiState.isLoading,
                onWorkOrderTapped = onWorkOrderTapped
            )
        }
    }

    uiState.errorMessage?.let { message ->
        LaunchedEffect(message) {
            viewModel.clearError()
        }
    }
}

// The green banner: greeting, three live counts and the two main actions
@Composable
private fun DashboardHeader(
    greeting: String,
    activeJobs: Int,
    pending: Int,
    inProgress: Int,
    dueSoon: Int,
    overdue: Int,
    onCreateWorkOrder: () -> Unit,
    onOrderStatus: () -> Unit
) {
    val onPrimary = MaterialTheme.colorScheme.onPrimary

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.primary,
                RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
            )
            .dotGrid(onPrimary)
            .padding(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp)
    ) {
        Text(
            text = "$greeting, Admin",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = onPrimary
        )
        Text(
            text = "You have $activeJobs active job${if (activeJobs == 1) "" else "s"}",
            style = MaterialTheme.typography.bodyMedium,
            color = onPrimary.copy(alpha = 0.85f)
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile(value = pending, label = "Pending", modifier = Modifier.weight(1f))
            StatTile(value = inProgress, label = "Started", modifier = Modifier.weight(1f))
            StatTile(value = dueSoon, label = "Due soon", modifier = Modifier.weight(1f))
            // Turns red as soon as there is something overdue
            StatTile(
                value = overdue,
                label = "Overdue",
                modifier = Modifier.weight(1f),
                tint = if (overdue > 0) OVERDUE_RED else MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.16f)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onCreateWorkOrder,
                modifier = Modifier.weight(1f),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.tertiary
                )
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Job")
            }
            OutlinedButton(
                onClick = onOrderStatus,
                modifier = Modifier.weight(1f),
                shape = CircleShape,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = onPrimary),
                border = BorderStroke(1.dp, onPrimary.copy(alpha = 0.7f))
            ) {
                Text("Order Status")
            }
        }
    }
}

@Composable
private fun StatTile(
    value: Int,
    label: String,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.16f)
) {
    val onPrimary = MaterialTheme.colorScheme.onPrimary
    Column(
        modifier = modifier
            .background(tint, RoundedCornerShape(14.dp))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "$value",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = onPrimary
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = onPrimary.copy(alpha = 0.85f)
        )
    }
}

// The rows under the header: a spinner while loading, an empty state, or one card per job
private fun LazyListScope.workOrderItems(
    workOrders: List<WorkOrder>,
    isLoading: Boolean,
    onWorkOrderTapped: (String) -> Unit
) {
    when {
        isLoading -> item(key = "loading") {
            Box(
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        }
        workOrders.isEmpty() -> item(key = "empty") {
            EmptyState(
                icon = Icons.AutoMirrored.Filled.List,
                title = "No active work orders",
                message = "Jobs you create will show up here."
            )
        }
        else -> items(items = workOrders, key = { it.workOrderId }) { workOrder ->
            // animateItem fades jobs in and out and slides the list when a job is added, claimed or finished
            Box(modifier = Modifier.animateItem().padding(horizontal = 16.dp)) {
                WorkOrderCard(
                    workOrder = workOrder,
                    onClick = { onWorkOrderTapped(workOrder.workOrderId) }
                )
            }
        }
    }
}

@Composable
internal fun WorkOrderCard(
    workOrder: WorkOrder,
    onClick: () -> Unit
) {
    val isNew = (System.currentTimeMillis() - workOrder.createdAt) < NEW_BADGE_THRESHOLD_MS
    val due = dueStatus(workOrder)
    val teamColor = workOrder.teamColour?.let {
        runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull()
    }

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            // Team colour indicator strip on left edge
            if (teamColor != null) {
                Box(
                    modifier = Modifier
                        .width(6.dp)
                        .fillMaxHeight()
                        .background(teamColor)
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = workOrder.clientName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isNew) NewBadge()
                        StatusBadge(status = workOrder.status)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (workOrder.contactPerson.isNotBlank()) {
                    Text(
                        text = "Contact: ${workOrder.contactPerson}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = workOrder.siteAddress,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                workOrder.assignedCrewName?.let { crew ->
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Assigned: $crew",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (workOrder.teamMembers.isNotEmpty()) {
                    Text(
                        text = "Team: ${workOrder.teamMembers.joinToString(", ")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (workOrder.scheduledTime.isNotBlank() || due != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (workOrder.scheduledTime.isNotBlank()) {
                            Text(
                                text = "Scheduled: ${workOrder.scheduledTime}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        due?.let { DueBadge(it) }
                    }
                }
                Text(
                    text = "Added: ${formatDateTime(workOrder.createdAt)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                StepTimes(workOrder)

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "R %.2f".format(workOrder.amountZAR),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

// Every step the crew has taken with its date and time; a claimed job that hasn't begun says so
@Composable
private fun StepTimes(order: WorkOrder) {
    val style = MaterialTheme.typography.labelSmall
    val colour = MaterialTheme.colorScheme.onSurfaceVariant
    listOf(
        "Claimed" to order.claimedAt,
        "On my way" to order.onTheWayAt,
        "Started" to order.startedAt,
        "Completed" to order.completedAt
    ).forEach { (label, millis) ->
        if (millis > 0) Text(text = "$label: ${formatDateTime(millis)}", style = style, color = colour)
    }
    if (order.startedAt > 0 && order.completedAt > 0) {
        Text(
            text = "Duration: ${formatDuration(order.startedAt, order.completedAt)}",
            style = style,
            color = colour
        )
    }
    if (order.status == "IN_PROGRESS" && order.startedAt == 0L) {
        Text(text = "Not started yet", style = style, color = colour)
    }
}

@Composable
internal fun StatusBadge(status: String) {
    val (label, color) = when (status) {
        "PENDING" -> "Pending" to Color(0xFFF59E0B)
        "IN_PROGRESS" -> "In Progress" to Color(0xFF3B82F6)
        "COMPLETED" -> "Completed" to Color(0xFF10B981)
        else -> status to Color.Gray
    }
    Pill(label, color)
}

// "Due today" and "Overdue" are red; "Due tomorrow" and "Due in 2 days" are orange
@Composable
internal fun DueBadge(due: DueStatus) {
    Pill(due.label, if (due.urgent) Color(0xFFDC2626) else Color(0xFFEA580C))
}

@Composable
private fun Pill(label: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = color
        )
    }
}

@Composable
private fun NewBadge() {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primary
    ) {
        Text(
            text = "NEW",
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimary
        )
    }
}