package com.example.workspacewizardsg.util

import java.net.URLEncoder

// WhatsApp texts to a client, built from fixed templates (no AI involved).
// Pure Kotlin so they can be unit tested; the screens only open the link.

// Address the contact person when there is one, otherwise the client
fun greetingName(contactPerson: String, clientName: String): String =
    contactPerson.trim().ifBlank { clientName.trim() }

fun onTheWayMessage(greeting: String, crewName: String, siteAddress: String): String =
    "Hi $greeting, this is $crewName from Workspace Wizards. We're on our way to $siteAddress."

fun jobStartedMessage(greeting: String, crewName: String, siteAddress: String): String =
    "Hi $greeting, $crewName from Workspace Wizards has started your job at $siteAddress."

fun adminJobMessage(greeting: String, siteAddress: String, scheduledTime: String): String =
    "Hi $greeting, this is Workspace Wizards about your job at $siteAddress" +
            (if (scheduledTime.isNotBlank()) " scheduled for $scheduledTime" else "") + "."

// WhatsApp click-to-chat link with the message filled in, or null when the phone number
// is not a valid South African number. %20 (not +) so spaces survive in the chat box.
fun whatsAppUrl(phone: String, message: String): String? {
    val number = normaliseSaPhone(phone)?.removePrefix("+") ?: return null
    val text = URLEncoder.encode(message, "UTF-8").replace("+", "%20")
    return "https://wa.me/$number?text=$text"
}

