package com.example.workspacewizardsg.uii

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

// A wa.me link opens WhatsApp when it is installed, otherwise the browser.
fun openWhatsAppChat(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        // Nothing on the phone can open the link; the step it followed is already saved
    }
}

