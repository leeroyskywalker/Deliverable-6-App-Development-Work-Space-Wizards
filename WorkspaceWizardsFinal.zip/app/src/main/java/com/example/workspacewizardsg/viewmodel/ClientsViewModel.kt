package com.example.workspacewizardsg.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.workspacewizardsg.model.Client
import com.example.workspacewizardsg.repository.ClientRepository
import com.example.workspacewizardsg.util.addressError
import com.example.workspacewizardsg.util.companyNameError
import com.example.workspacewizardsg.util.normaliseSaPhone
import com.example.workspacewizardsg.util.personNameError
import com.example.workspacewizardsg.util.phoneError
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ClientsViewModel(
    private val clientRepository: ClientRepository = ClientRepository()
) : ViewModel() {

    // null = still loading
    val clients: StateFlow<List<Client>?> = clientRepository.observeClients()
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    // Returns a message for the first problem found, or null when the form is valid.
    // existingId is the client being edited (null when adding), so a client never clashes with itself.
    fun validateClient(
        existingId: String?,
        companyName: String,
        contactPerson: String,
        phone: String,
        siteAddress: String
    ): String? {
        // The form checks these as the user types; they are repeated here so nothing invalid
        // can be saved even if this is called from somewhere else
        companyNameError(companyName)?.let { return it }
        personNameError(contactPerson, "Contact person")?.let { return it }
        phoneError(phone)?.let { return it }
        addressError(siteAddress)?.let { return it }
        val normalisedPhone = normaliseSaPhone(phone) ?: return "Enter a valid phone number"

        val duplicate = clients.value.orEmpty().any {
            it.clientId != existingId && (
                    it.companyName.trim().equals(companyName.trim(), ignoreCase = true) ||
                            normaliseSaPhone(it.phone) == normalisedPhone
                    )
        }
        if (duplicate) return "A client with this company name or phone number already exists"
        return null
    }

    // Call validateClient first. Adds a new client when existing is null, otherwise updates it.
    fun saveClient(
        existing: Client?,
        companyName: String,
        contactPerson: String,
        phone: String,
        siteAddress: String
    ) {
        val normalisedPhone = normaliseSaPhone(phone) ?: return
        val client = Client(
            clientId = existing?.clientId.orEmpty(),
            companyName = companyName.trim(),
            contactPerson = contactPerson.trim(),
            phone = normalisedPhone,
            siteAddress = siteAddress.trim()
        )
        viewModelScope.launch {
            val result = if (existing == null) clientRepository.addClient(client).map { }
            else clientRepository.updateClient(client)
            result.fold(
                onSuccess = { _message.value = if (existing == null) "Client added" else "Client updated" },
                onFailure = { _message.value = "Could not save the client. Check your connection." }
            )
        }
    }

    fun deleteClient(client: Client) {
        viewModelScope.launch {
            clientRepository.deleteClient(client.clientId).fold(
                onSuccess = { _message.value = "Client deleted" },
                onFailure = { error ->
                    _message.value = if (error is IllegalStateException) error.message
                    else "Could not delete the client. Check your connection."
                }
            )
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}