package com.example.workspacewizardsg.model

// Notifications for the admin are addressed to this value; a crew's are addressed to its user ID.
const val ADMIN_AUDIENCE = "ADMIN"

// One short message in the bell. The repository stores it field by field so that
// createdAt is the server's time, which is why this is not written to Firestore as an object.
data class AppNotification(
    val notificationId: String,
    val message: String,
    val workOrderId: String?,
    val read: Boolean,
    val createdAt: Long
)